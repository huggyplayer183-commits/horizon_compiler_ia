"""huc command line interface."""
from __future__ import annotations

import argparse
import json
import os
import sys

from . import __version__
from .core.errors import HucError
from .core.report import Level, Report


def _emit(rep: Report, as_json: bool) -> None:
    print(json.dumps(rep.to_dict(), indent=2, default=str) if as_json else rep.format_text())


def _analyze(path: str) -> Report:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".jar",):
        from .java.analyzer import analyze_jar
        return analyze_jar(path, os.path.basename(path))
    if ext in (".mcaddon", ".mcpack") or os.path.isdir(path):
        from .bedrock.analyzer import analyze_bedrock
        return analyze_bedrock(path)
    if ext == ".zip":
        import zipfile
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
        if any(n.endswith("manifest.json") for n in names):
            from .bedrock.analyzer import analyze_bedrock
            return analyze_bedrock(path)
        from .java.analyzer import analyze_jar
        return analyze_jar(path, os.path.basename(path))
    if ext in (".obj", ".gltf", ".glb", ".bbmodel", ".fbx", ".hurm"):
        from .models import load_model
        m = load_model(path)
        rep = Report(path, "model")
        rep.data = {"name": m.name, "meshes": len(m.meshes), "cubes": len(m.cubes),
                    "vertices": sum(x.vertex_count for x in m.meshes),
                    "triangles": sum(len(x.indices) // 3 for x in m.meshes),
                    "textures": len(m.textures), "materials": len(m.materials),
                    "source_format": m.meta.get("source_format")}
        for w in m.meta.get("warnings", []):
            rep.add("MODEL_WARNING", Level.PARTIAL, w)
        return rep
    raise HucError(f"don't know how to analyze {path!r}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="huc", description="Horizon Universal Compiler")
    ap.add_argument("--version", action="version", version=f"huc {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze", help="analyze a jar, bedrock pack or model file")
    a.add_argument("path")
    a.add_argument("--json", action="store_true")

    p = sub.add_parser("plan", help="plan converting a mod jar to a target")
    p.add_argument("jar")
    p.add_argument("--loader", default=None)
    p.add_argument("--mc", default=None, help="target Minecraft version")
    p.add_argument("--target-profile", default=None, help="JSON profile (e.g. for Horizon)")
    p.add_argument("--json", action="store_true")

    m = sub.add_parser("convert-model", help="convert between model formats")
    m.add_argument("input")
    m.add_argument("output", help="extension decides format: .hurm .obj .glb .json (java block model)")
    m.add_argument("--namespace", default="huc")

    mg = sub.add_parser("migrate-assets", help="migrate 1.12-style assets to 1.13+ layout")
    mg.add_argument("input", help="directory, .jar or .zip")
    mg.add_argument("output", help="output directory")
    mg.add_argument("--mc", required=True, help="target Minecraft version")
    mg.add_argument("--pack-format", type=int, default=None)
    mg.add_argument("--json", action="store_true")

    args = ap.parse_args(argv)
    try:
        if args.cmd == "analyze":
            _emit(_analyze(args.path), args.json)
        elif args.cmd == "plan":
            from .java.analyzer import analyze_jar
            from .knowledge.versions import TargetProfile
            from .planner.plan import plan_java_conversion
            if args.target_profile:
                tgt = TargetProfile.from_file(args.target_profile)
            elif args.loader and args.mc:
                tgt = TargetProfile.for_loader(args.loader, args.mc)
            else:
                ap.error("plan needs --target-profile or both --loader and --mc")
            plan = plan_java_conversion(analyze_jar(args.jar, os.path.basename(args.jar)), tgt)
            if args.json:
                print(json.dumps(plan.to_dict(), indent=2))
            else:
                print(f"{plan.source}  ->  {plan.target}   automatic: {plan.feasible_automatically}")
                for s in plan.steps:
                    tool = f"  [tool: {s.tool}]" if s.tool else ""
                    print(f"  {s.level.value:<11} {s.title}{tool}\n              {s.detail}")
        elif args.cmd == "convert-model":
            return _convert_model(args)
        elif args.cmd == "migrate-assets":
            from .assets.migrate import migrate_assets
            res = migrate_assets(args.input, args.mc, args.pack_format)
            res.write_to(args.output)
            _emit(res.report, args.json)
    except HucError as e:
        print(f"huc: error: {e}", file=sys.stderr)
        return 2
    except (OSError, ValueError) as e:
        print(f"huc: error: {e}", file=sys.stderr)
        return 1
    return 0


def _convert_model(args) -> int:
    from .hurm.exporters import model_to_glb, model_to_java_block, model_to_obj
    from .hurm.format import write_hurm
    from .models import load_model
    model = load_model(args.input)
    ext = os.path.splitext(args.output)[1].lower()
    if ext == ".hurm":
        data = write_hurm(model)
    elif ext == ".obj":
        data = model_to_obj(model).encode()
    elif ext == ".glb":
        data = model_to_glb(model)
    elif ext == ".json":
        out, rep = model_to_java_block(model, args.namespace)
        print(rep.format_text())
        data = json.dumps(out, indent=2).encode()
    else:
        raise HucError(f"unsupported output extension {ext!r}")
    with open(args.output, "wb") as f:
        f.write(data)
    for w in model.meta.get("warnings", []):
        print(f"warning: {w}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
