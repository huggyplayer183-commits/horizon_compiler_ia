"""Bedrock add-on / resource-pack analyzer (.mcaddon, .mcpack, .zip or a directory).

Reads manifests (JSON with comments), validates their structure, inventories content
and parses geometry files. It analyses only: converting Bedrock content to Java is a
reconstruction task and is reported as such, never faked.
"""
from __future__ import annotations

import os
import re
from collections import Counter
from typing import Any

from ..core.errors import MalformedInput
from ..core.jsonc import loads_jsonc
from ..core.report import Level, Report
from ..java.analyzer import MAX_ENTRY, open_zip_safely

UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
MODULE_TYPES = {"resources", "data", "script", "client_data", "interface", "world_template",
                "skin_pack", "invalid", "javascript"}
_CONTENT_DIRS = {
    "entities": "entities", "entity": "client_entities", "blocks": "blocks", "items": "items",
    "animations": "animations", "animation_controllers": "animation_controllers",
    "models": "models", "textures": "textures", "sounds": "sounds", "ui": "ui",
    "scripts": "scripts", "loot_tables": "loot_tables", "recipes": "recipes",
    "spawn_rules": "spawn_rules", "particles": "particles", "render_controllers": "render_controllers",
    "texts": "texts", "functions": "functions", "structures": "structures", "biomes": "biomes",
}


def _load_files(src: str) -> dict[str, bytes]:
    files: dict[str, bytes] = {}
    if os.path.isdir(src):
        for root, _d, fs in os.walk(src):
            for f in fs:
                p = os.path.join(root, f)
                if os.path.getsize(p) > MAX_ENTRY:
                    continue
                with open(p, "rb") as fh:
                    files[os.path.relpath(p, src).replace(os.sep, "/")] = fh.read()
        return files
    z = open_zip_safely(src)
    for i in z.infolist():
        if not i.is_dir() and i.file_size <= MAX_ENTRY:
            files[i.filename] = z.read(i)
    # nested packs inside .mcaddon
    for name in list(files):
        if name.lower().endswith((".mcpack", ".zip")):
            try:
                inner = open_zip_safely(files[name])
            except Exception:  # noqa: BLE001
                continue
            for i in inner.infolist():
                if not i.is_dir() and i.file_size <= MAX_ENTRY:
                    files[f"{name}!/{i.filename}"] = inner.read(i)
    return files


def validate_manifest(m: Any, rep: Report, path: str) -> dict[str, Any]:
    info: dict[str, Any] = {"path": path}
    if not isinstance(m, dict):
        rep.add("MANIFEST_NOT_OBJECT", Level.MANUAL, "manifest.json root must be an object", path)
        return info
    fv = m.get("format_version")
    info["format_version"] = fv
    if fv not in (1, 2):
        rep.add("MANIFEST_FORMAT_VERSION", Level.PARTIAL, f"format_version {fv!r} is not 1 or 2", path)
    h = m.get("header")
    if not isinstance(h, dict):
        rep.add("MANIFEST_NO_HEADER", Level.MANUAL, "missing header", path)
        return info
    info["name"] = h.get("name")
    info["uuid"] = h.get("uuid")
    if not isinstance(h.get("uuid"), str) or not UUID_RE.match(h["uuid"]):
        rep.add("MANIFEST_BAD_UUID", Level.MANUAL, f"header.uuid invalid: {h.get('uuid')!r}", path)
    if not _is_version(h.get("version")):
        rep.add("MANIFEST_BAD_VERSION", Level.MANUAL, "header.version must be [major, minor, patch] or semver", path)
    if "min_engine_version" in h:
        info["min_engine_version"] = h["min_engine_version"]
    types = []
    seen = set()
    for mod in m.get("modules", []) or []:
        t = mod.get("type") if isinstance(mod, dict) else None
        types.append(t)
        if t not in MODULE_TYPES:
            rep.add("MANIFEST_UNKNOWN_MODULE", Level.PARTIAL, f"unknown module type {t!r}", path)
        u = mod.get("uuid") if isinstance(mod, dict) else None
        if not isinstance(u, str) or not UUID_RE.match(u):
            rep.add("MANIFEST_MODULE_UUID", Level.MANUAL, f"module uuid invalid: {u!r}", path)
        elif u in seen or u == h.get("uuid"):
            rep.add("MANIFEST_DUP_UUID", Level.MANUAL, "module uuid duplicates another uuid", path)
        seen.add(u)
    info["module_types"] = types
    if not types:
        rep.add("MANIFEST_NO_MODULES", Level.PARTIAL, "no modules declared", path)
    deps = []
    for d in m.get("dependencies", []) or []:
        if isinstance(d, dict):
            deps.append(d.get("uuid") or d.get("module_name"))
    info["dependencies"] = deps
    info["script_modules"] = [d.get("module_name") for d in (m.get("dependencies") or [])
                              if isinstance(d, dict) and d.get("module_name")]
    return info


def _is_version(v: Any) -> bool:
    if isinstance(v, list):
        return len(v) == 3 and all(isinstance(x, int) and x >= 0 for x in v)
    return isinstance(v, str) and re.match(r"^\d+\.\d+\.\d+", v) is not None


def analyze_bedrock(src: str) -> Report:
    rep = Report(src, "bedrock-pack")
    try:
        files = _load_files(src)
    except Exception as e:  # noqa: BLE001
        raise MalformedInput(f"cannot read bedrock pack: {e}") from e
    manifests = sorted(p for p in files if p.endswith("manifest.json"))
    if not manifests:
        rep.add("NO_MANIFEST", Level.UNSUPPORTED, "no manifest.json: not a Bedrock pack")
        return rep
    packs = []
    for mp in manifests:
        try:
            packs.append(validate_manifest(loads_jsonc(files[mp]), rep, mp))
        except MalformedInput as e:
            rep.add("MANIFEST_BAD_JSON", Level.MANUAL, str(e), mp)
    rep.data["packs"] = packs

    inv: Counter[str] = Counter()
    geos = {"files": 0, "geometries": 0, "bones": 0, "cubes": 0, "formats": Counter()}
    for p, data in files.items():
        if not p.endswith(".json") and not p.endswith((".js", ".png", ".tga", ".ogg", ".fsb", ".lang")):
            continue
        parts = p.replace("!/", "/").split("/")
        for d in parts[:-1]:
            if d in _CONTENT_DIRS:
                inv[_CONTENT_DIRS[d]] += 1
                break
        if p.endswith(".json") and "models" in parts[:-1]:
            _geometry(data, p, rep, geos)
    rep.data["content"] = dict(inv)
    rep.data["geometry"] = {**geos, "formats": dict(geos["formats"])}
    if geos["cubes"]:
        rep.add("GEOMETRY_FOUND", Level.INFO,
                f"{geos['geometries']} geometry(ies), {geos['bones']} bones, {geos['cubes']} cubes")

    kinds = {t for p in packs for t in p.get("module_types", [])}
    if "script" in kinds or "javascript" in kinds or inv["scripts"]:
        rep.add("SCRIPTS", Level.MANUAL,
                "Bedrock scripting API (JavaScript) has no Java equivalent: reimplement behaviour in the target loader")
    if inv["entities"] or inv["blocks"] or inv["items"]:
        rep.add("BEHAVIOUR_DEFS", Level.MANUAL,
                "Bedrock component-based entity/block/item definitions must be rebuilt in Java code or data")
    if inv["textures"]:
        rep.add("TEXTURES_REUSABLE", Level.PARTIAL,
                "PNG textures are reusable, but paths/naming (textures/blocks, texture_list, terrain_texture.json) differ from Java")
    if inv["animations"] or inv["animation_controllers"]:
        rep.add("ANIMATIONS_MANUAL", Level.MANUAL,
                "Molang-based animations/controllers do not map to Java; re-author them")
    if inv["models"] and not geos["cubes"]:
        rep.add("MODEL_FILES_UNPARSED", Level.PARTIAL, "model JSON present but no geometry could be parsed")
    return rep


def _geometry(data: bytes, path: str, rep: Report, geos: dict) -> None:
    try:
        d = loads_jsonc(data)
    except MalformedInput:
        rep.add("GEOMETRY_BAD_JSON", Level.PARTIAL, "geometry file is not valid JSON", path)
        return
    if not isinstance(d, dict):
        return
    fv = str(d.get("format_version", ""))
    entries: list[dict] = []
    if "minecraft:geometry" in d:  # 1.12.0+
        entries = [e for e in d["minecraft:geometry"] if isinstance(e, dict)]
    else:  # legacy 1.8.0 style: "geometry.name": {bones: [...]}
        entries = [v for k, v in d.items() if k.startswith("geometry.") and isinstance(v, dict)]
    if not entries:
        return
    geos["files"] += 1
    geos["formats"][fv or "unknown"] += 1
    for e in entries:
        geos["geometries"] += 1
        for b in e.get("bones", []) or []:
            geos["bones"] += 1
            geos["cubes"] += len(b.get("cubes", []) or [])
