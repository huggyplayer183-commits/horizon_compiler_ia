"""Exporters from the IR: tessellation of cubes, OBJ/GLB, and Java block-model JSON."""
from __future__ import annotations

import copy
import math
from typing import Any

from ..core.errors import ConversionImpossible
from ..core.report import Level, Report
from ..models.gltf import write_glb
from ..models.ir import FACES, Cube, Mesh, Model
from ..models.obj import write_obj

# corner order for each face seen from OUTSIDE: top-left, top-right, bottom-right, bottom-left
def _corners(f: str, a, b):
    x1, y1, z1 = a
    x2, y2, z2 = b
    return {
        "north": ((x2, y2, z1), (x1, y2, z1), (x1, y1, z1), (x2, y1, z1)),
        "south": ((x1, y2, z2), (x2, y2, z2), (x2, y1, z2), (x1, y1, z2)),
        "east":  ((x2, y2, z2), (x2, y2, z1), (x2, y1, z1), (x2, y1, z2)),
        "west":  ((x1, y2, z1), (x1, y2, z2), (x1, y1, z2), (x1, y1, z1)),
        "up":    ((x1, y2, z1), (x2, y2, z1), (x2, y2, z2), (x1, y2, z2)),
        "down":  ((x1, y1, z2), (x2, y1, z2), (x2, y1, z1), (x1, y1, z1)),
    }[f]


_NORMALS = {"north": (0, 0, -1), "south": (0, 0, 1), "east": (1, 0, 0),
            "west": (-1, 0, 0), "up": (0, 1, 0), "down": (0, -1, 0)}


def _rot_matrix(rot_deg) -> list[list[float]]:
    """Blockbench Euler order ZYX (matrix = Rz*Ry*Rx). Assumption documented in HURM_SPEC."""
    rx, ry, rz = (math.radians(a) for a in rot_deg)
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = [[1, 0, 0], [0, cx, -sx], [0, sx, cx]]
    Ry = [[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]]
    Rz = [[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]]

    def mul(A, B):
        return [[sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    return mul(Rz, mul(Ry, Rx))


def tessellate_cube(c: Cube, res: tuple[float, float], material_for_texture) -> list[Mesh]:
    """One Mesh per distinct texture used by the cube's faces."""
    R = _rot_matrix(c.rotation) if any(c.rotation) else None
    per_tex: dict[int, Mesh] = {}
    for f in FACES:
        fd = c.faces.get(f)
        if not fd:
            continue
        tex = fd.get("texture", -1)
        mesh = per_tex.setdefault(tex, Mesh(name=f"{c.name}", material=material_for_texture(tex)))
        corners = _corners(f, c.from_, c.to)
        normal = _NORMALS[f]
        if R:
            ox, oy, oz = c.origin
            corners = tuple(tuple(
                sum(R[i][j] * (p[j] - o) for j, o in enumerate((ox, oy, oz))) + (ox, oy, oz)[i]
                for i in range(3)) for p in corners)
            normal = tuple(sum(R[i][j] * normal[j] for j in range(3)) for i in range(3))
        u1, v1, u2, v2 = fd.get("uv", (0, 0, res[0], res[1]))
        uvs = ((u1, v1), (u2, v1), (u2, v2), (u1, v2))
        base = mesh.vertex_count
        for p, (u, v) in zip(corners, uvs):
            mesh.positions.extend(p)
            mesh.normals.extend(normal)
            mesh.uvs.extend((u / res[0], v / res[1]))
        mesh.indices.extend((base, base + 3, base + 2, base, base + 2, base + 1))  # TL,BL,BR / TL,BR,TR
    return list(per_tex.values())


def tessellated(model: Model) -> Model:
    """Return a copy of the model where cubes have been converted into triangle meshes."""
    out = copy.deepcopy(model)
    res = tuple(model.meta.get("resolution", (16, 16)))
    cubes, out.cubes = out.cubes, []
    mat_for_tex = {m.texture: i for i, m in enumerate(out.materials) if m.texture >= 0}
    for c in cubes:
        out.meshes.extend(tessellate_cube(c, res, lambda t: mat_for_tex.get(t, -1)))
    if any(any(c.rotation) and sum(1 for a in c.rotation if a) > 1 for c in cubes):
        out.warnings.append("multi-axis cube rotation applied with assumed ZYX order")
    out.validate()
    return out


def model_to_obj(model: Model) -> str:
    return write_obj(tessellated(model))


def model_to_glb(model: Model) -> bytes:
    return write_glb(tessellated(model))


# ---------------------------------------------------------------- Java block model

_JAVA_ANGLES = (-45.0, -22.5, 0.0, 22.5, 45.0)


def model_to_java_block(model: Model, namespace: str = "huc", texture_dir: str = "block") -> tuple[dict, Report]:
    """Convert a *cube-only* model into a vanilla Java block/item model JSON.

    Vanilla models can only contain cuboids, so meshes are reported UNSUPPORTED.
    The returned dict is only emitted when it is faithful; otherwise ConversionImpossible.
    """
    rep = Report(model.name, "java-block-model")
    if model.meshes:
        rep.add("JBM_MESHES", Level.UNSUPPORTED,
                f"{len(model.meshes)} triangle mesh(es) cannot be expressed as a vanilla Java model; "
                "rebuild as cuboids or use a custom renderer")
    if not model.cubes:
        raise ConversionImpossible("model has no cubes; nothing can be exported as a Java block model")
    res_w, res_h = model.meta.get("resolution", (16, 16))
    elements = []
    for c in model.cubes:
        el: dict[str, Any] = {"name": c.name, "from": c.from_, "to": c.to}
        if any(v < -16 or v > 32 for v in c.from_ + c.to):
            rep.add("JBM_RANGE", Level.MANUAL,
                    "coordinates outside the vanilla -16..32 range; split the element", c.name)
        nz = [(i, a) for i, a in enumerate(c.rotation) if abs(a) > 1e-9]
        if len(nz) == 1 and any(abs(nz[0][1] - a) < 1e-6 for a in _JAVA_ANGLES):
            axis = "xyz"[nz[0][0]]
            el["rotation"] = {"origin": c.origin, "axis": axis, "angle": nz[0][1]}
        elif nz:
            rep.add("JBM_ROTATION", Level.MANUAL,
                    f"rotation {c.rotation} not representable (single axis, step 22.5, max 45)", c.name)
        faces = {}
        for f, fd in c.faces.items():
            face: dict[str, Any] = {
                "uv": [round(fd["uv"][0] * 16 / res_w, 6), round(fd["uv"][1] * 16 / res_h, 6),
                       round(fd["uv"][2] * 16 / res_w, 6), round(fd["uv"][3] * 16 / res_h, 6)],
                "texture": f"#{fd['texture']}"}
            if fd.get("rotation"):
                face["rotation"] = fd["rotation"]
            faces[f] = face
        el["faces"] = faces
        elements.append(el)
    textures = {str(i): f"{namespace}:{texture_dir}/{_slug(t.name)}" for i, t in enumerate(model.textures)}
    if model.textures:
        textures["particle"] = textures["0"]
    out = {"textures": textures, "elements": elements}
    if rep.count(Level.MANUAL) or rep.count(Level.UNSUPPORTED):
        rep.add("JBM_PARTIAL", Level.PARTIAL, "output omits or distorts the flagged parts")
    else:
        rep.add("JBM_OK", Level.AUTO, f"{len(elements)} cube(s) converted")
    return out, rep


def _slug(name: str) -> str:
    base = name.rsplit(".", 1)[0] if name.lower().endswith((".png", ".jpg", ".tga")) else name
    return "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in base.lower())
