"""HUC-RM (.hurm) binary container - see docs/HURM_SPEC.md.

Layout:  "HURM" | u16 version | u16 flags | chunk* | HEND chunk
Chunk:   tag[4] | u32 length | payload | u32 crc32(payload)   (all little-endian)
Chunk tags follow the PNG rule: an UPPERCASE first letter marks a *critical* chunk
(unknown => reject), lowercase marks an *ancillary* chunk (unknown => skip).
"""
from __future__ import annotations

import json
import struct
import zlib

from ..core.errors import MalformedInput, UnsupportedFormat
from ..models.ir import Cube, Material, Mesh, Model, Texture

MAGIC = b"HURM"
VERSION = 1
MAX_CHUNK = 1 << 30


def _chunk(tag: bytes, payload: bytes) -> bytes:
    assert len(tag) == 4
    return tag + struct.pack("<I", len(payload)) + payload + struct.pack("<I", zlib.crc32(payload) & 0xFFFFFFFF)


def _jsonable_meta(meta: dict) -> dict:
    return json.loads(json.dumps(meta, default=str))


def write_hurm(model: Model) -> bytes:
    model.validate()
    out = bytearray(MAGIC + struct.pack("<HH", VERSION, 0))
    meta = {"name": model.name, "generator": "HUC", "meta": _jsonable_meta(model.meta)}
    out += _chunk(b"META", json.dumps(meta, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
    for t in model.textures:
        nm = t.name.encode("utf-8")
        out += _chunk(b"TEXR", struct.pack("<H", len(nm)) + nm + t.data)
    mats = [{"name": m.name, "texture": m.texture} for m in model.materials]
    out += _chunk(b"MATL", json.dumps(mats, separators=(",", ":")).encode("utf-8"))
    for m in model.meshes:
        nm = m.name.encode("utf-8")
        flags = (1 if m.normals else 0) | (2 if m.uvs else 0)
        p = bytearray(struct.pack("<H", len(nm)) + nm)
        p += struct.pack("<iIIB", m.material, m.vertex_count, len(m.indices), flags)
        p += struct.pack(f"<{len(m.positions)}f", *m.positions)
        if m.normals:
            p += struct.pack(f"<{len(m.normals)}f", *m.normals)
        if m.uvs:
            p += struct.pack(f"<{len(m.uvs)}f", *m.uvs)
        p += struct.pack(f"<{len(m.indices)}I", *m.indices)
        out += _chunk(b"MESH", bytes(p))
    if model.cubes:
        out += _chunk(b"CUBE", json.dumps([c.to_dict() for c in model.cubes],
                                          separators=(",", ":")).encode("utf-8"))
    out += _chunk(b"HEND", b"")
    return bytes(out)


def iter_chunks(data: bytes):
    """Yield (tag, payload) after verifying framing and CRC. Does not interpret payloads."""
    if len(data) < 8 or data[:4] != MAGIC:
        raise MalformedInput("not a .hurm file (bad magic)")
    version, _flags = struct.unpack_from("<HH", data, 4)
    if version > VERSION or version == 0:
        raise UnsupportedFormat(f".hurm version {version} (reader supports <= {VERSION})")
    off, seen_end = 8, False
    while off < len(data):
        if seen_end:
            raise MalformedInput("data after HEND chunk")
        if off + 8 > len(data):
            raise MalformedInput("truncated chunk header")
        tag = data[off:off + 4]
        (length,) = struct.unpack_from("<I", data, off + 4)
        if length > MAX_CHUNK or off + 8 + length + 4 > len(data):
            raise MalformedInput(f"chunk {tag!r} truncated or oversized")
        payload = data[off + 8: off + 8 + length]
        (crc,) = struct.unpack_from("<I", data, off + 8 + length)
        if crc != zlib.crc32(payload) & 0xFFFFFFFF:
            raise MalformedInput(f"CRC mismatch in chunk {tag!r}")
        yield tag, payload
        seen_end = tag == b"HEND"
        off += 12 + length
    if not seen_end:
        raise MalformedInput("missing HEND chunk")


class _P:
    def __init__(self, b: bytes):
        self.b, self.o = b, 0

    def take(self, n: int) -> bytes:
        if self.o + n > len(self.b):
            raise MalformedInput("chunk payload truncated")
        s = self.b[self.o:self.o + n]
        self.o += n
        return s

    def unpack(self, fmt: str):
        return struct.unpack("<" + fmt, self.take(struct.calcsize(fmt)))


def read_hurm(data: bytes) -> Model:
    model: Model | None = None
    for tag, payload in iter_chunks(data):
        if tag == b"META":
            try:
                m = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                raise MalformedInput(f"bad META chunk: {e}") from e
            model = Model(name=m.get("name", "model"), meta=m.get("meta", {}))
        elif model is None:
            raise MalformedInput("META chunk must come first")
        elif tag == b"TEXR":
            p = _P(payload)
            (n,) = p.unpack("H")
            name = p.take(n).decode("utf-8")
            model.textures.append(Texture(name, payload[p.o:]))
        elif tag == b"MATL":
            for m in json.loads(payload.decode("utf-8")):
                model.materials.append(Material(m["name"], int(m["texture"])))
        elif tag == b"MESH":
            p = _P(payload)
            (n,) = p.unpack("H")
            name = p.take(n).decode("utf-8")
            mat, vc, ic, flags = p.unpack("iIIB")
            if vc * 12 > len(payload) or ic * 4 > len(payload):
                raise MalformedInput("MESH counts exceed payload")
            mesh = Mesh(name=name, material=mat)
            mesh.positions = list(p.unpack(f"{vc * 3}f"))
            if flags & 1:
                mesh.normals = list(p.unpack(f"{vc * 3}f"))
            if flags & 2:
                mesh.uvs = list(p.unpack(f"{vc * 2}f"))
            mesh.indices = list(p.unpack(f"{ic}I"))
            if p.o != len(payload):
                raise MalformedInput("trailing bytes in MESH chunk")
            model.meshes.append(mesh)
        elif tag == b"CUBE":
            model.cubes = [Cube.from_dict(c) for c in json.loads(payload.decode("utf-8"))]
        elif tag == b"HEND":
            pass
        elif tag[0:1].isupper():
            raise UnsupportedFormat(f"unknown critical chunk {tag!r}")
        # lowercase first letter = ancillary: skipped on purpose
    if model is None:
        raise MalformedInput("missing META chunk")
    model.validate()
    return model
