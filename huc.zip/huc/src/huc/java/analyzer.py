"""Mod JAR analyzer: loader detection, metadata, API usage, mapping scheme, resources.

Everything reported is observed (metadata file or bytecode), never assumed. Where a
fact can only be guessed it is labelled as a hint.
"""
from __future__ import annotations

import io
import json
import re
import tomllib
import zipfile
from collections import Counter
from typing import Any

from ..core.errors import MalformedInput
from ..core.jsonc import loads_jsonc
from ..core.report import Level, Report
from .classfile import parse_class
from .signatures import API_PREFIXES, MOD_ANNOTATIONS, RE_NOTCH_CLASS, RE_SRG

MAX_ENTRY = 64 * 1024 * 1024
MAX_TOTAL = 2 * 1024 * 1024 * 1024
MAX_ENTRIES = 200_000
_VER = re.compile(r"\d+\.\d+(?:\.\d+)?")


def open_zip_safely(path_or_bytes) -> zipfile.ZipFile:
    z = zipfile.ZipFile(io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, (bytes, bytearray)) else path_or_bytes)
    infos = z.infolist()
    if len(infos) > MAX_ENTRIES:
        raise MalformedInput("archive has too many entries")
    if sum(i.file_size for i in infos) > MAX_TOTAL:
        raise MalformedInput("archive expands beyond the safety limit")
    return z


def _read(z: zipfile.ZipFile, name: str) -> bytes:
    info = z.getinfo(name)
    if info.file_size > MAX_ENTRY:
        raise MalformedInput(f"{name}: entry too large")
    return z.read(name)


def analyze_jar(path_or_bytes, subject: str = "mod.jar") -> Report:
    rep = Report(subject, "java-mod")
    try:
        z = open_zip_safely(path_or_bytes)
    except zipfile.BadZipFile as e:
        raise MalformedInput(f"not a valid JAR/ZIP: {e}") from e
    names = z.namelist()
    nameset = set(names)
    loaders: list[str] = []
    meta: dict[str, Any] = {}

    # ---- metadata files
    if "fabric.mod.json" in nameset:
        loaders.append("fabric")
        meta["fabric"] = _fabric(z, rep)
    if "quilt.mod.json" in nameset:
        loaders.append("quilt")
        try:
            q = json.loads(_read(z, "quilt.mod.json"))["quilt_loader"]
            meta["quilt"] = {"id": q.get("id"), "version": q.get("version")}
        except (KeyError, json.JSONDecodeError, TypeError):
            rep.add("QUILT_META_BAD", Level.PARTIAL, "quilt.mod.json unreadable", "quilt.mod.json")
    if "META-INF/neoforge.mods.toml" in nameset:
        loaders.append("neoforge")
        meta["neoforge"] = _toml(z, "META-INF/neoforge.mods.toml", rep)
    if "META-INF/mods.toml" in nameset:
        t = _toml(z, "META-INF/mods.toml", rep)
        is_neo = any(d.get("modId") == "neoforge" for deps in t.get("dependencies", {}).values() for d in deps)
        loader = "neoforge" if is_neo else "forge"
        if loader not in loaders:
            loaders.append(loader)
        meta[loader] = t
    if "mcmod.info" in nameset:
        loaders.append("forge-legacy")
        meta["forge-legacy"] = _mcmod_info(z, rep)
    rep.data["loaders"] = loaders
    rep.data["metadata"] = meta
    if not loaders:
        rep.add("NO_LOADER_METADATA", Level.INFO, "no mod metadata file found (library, coremod, or unknown loader)")
    elif len(loaders) > 1:
        rep.add("MULTI_LOADER", Level.INFO, "jar declares several loaders: " + ", ".join(loaders))

    # ---- bytecode scan
    majors: Counter[int] = Counter()
    api: Counter[str] = Counter()
    mc_classes: set[str] = set()
    annotations: set[str] = set()
    srg = notch = intermediary = 0
    bad = 0
    n_classes = 0
    for n in names:
        if not n.endswith(".class") or n.startswith("META-INF/versions/") or n.endswith("module-info.class"):
            continue
        try:
            ci = parse_class(_read(z, n))
        except MalformedInput as e:
            bad += 1
            rep.add("CLASS_UNREADABLE", Level.PARTIAL, str(e), n)
            continue
        n_classes += 1
        majors[ci.major] += 1
        for ref in ci.class_refs | set(ci.interfaces) | ({ci.super_name} if ci.super_name else set()):
            for label, prefix in API_PREFIXES:
                if ref.startswith(prefix):
                    api[label] += 1
                    if label == "minecraft":
                        mc_classes.add(ref)
                    break
        for u in ci.utf8:
            if u in MOD_ANNOTATIONS:
                annotations.add(MOD_ANNOTATIONS[u])
        for name, _d in ci.methods + ci.fields:
            if RE_SRG.match(name):
                srg += 1
            elif re.match(r"^(method|field)_\d+$", name):
                intermediary += 1
        simple = ci.name.rsplit("/", 1)[-1]
        if "/" not in ci.name and RE_NOTCH_CLASS.match(simple):
            notch += 1
    rep.data["class_count"] = n_classes
    rep.data["class_major_versions"] = sorted(majors)
    rep.data["max_java_version"] = (max(majors) - 44) if majors else None
    rep.data["api_usage"] = dict(api)
    rep.data["mod_annotations"] = sorted(annotations)
    rep.data["minecraft_class_refs"] = len(mc_classes)

    scheme = "unknown"
    if srg:
        scheme = "srg"
    elif intermediary:
        scheme = "intermediary"
    elif n_classes and notch > n_classes * 0.5:
        scheme = "notch-obfuscated"
    elif mc_classes:
        scheme = "named (yarn/mojmap/mcp - not distinguishable from bytecode)"
    rep.data["mapping_scheme"] = scheme
    if scheme == "srg":
        rep.add("MAPPING_SRG", Level.INFO, "SRG-mapped bytecode (func_/field_ names): legacy Forge/MCP lineage")
    if n_classes == 0:
        rep.add("NO_CLASSES", Level.INFO, "jar contains no classes (resource-only)")

    # ---- loader inference from bytecode when metadata is absent/contradictory
    inferred = [lab for lab in ("forge-legacy-fml", "forge", "neoforge", "fabric-api", "fabric-loader", "quilt") if api[lab]]
    rep.data["loader_by_bytecode"] = inferred
    if loaders and inferred:
        meta_family = {l.split("-")[0] for l in loaders}
        code_family = {l.split("-")[0] for l in inferred}
        if not meta_family & code_family and not (meta_family <= {"fabric", "quilt"} and code_family & {"fabric", "quilt"}):
            rep.add("LOADER_MISMATCH", Level.PARTIAL,
                    f"metadata says {sorted(meta_family)} but bytecode references {sorted(code_family)}")

    # ---- minecraft version hint
    hint = _mc_hint(meta)
    rep.data["mc_version_hint"] = hint

    # ---- resources
    rep.data["resources"] = _resources(names)
    if "pack.mcmeta" in nameset:
        try:
            rep.data["pack_format"] = loads_jsonc(_read(z, "pack.mcmeta")).get("pack", {}).get("pack_format")
        except (MalformedInput, AttributeError):
            rep.add("PACK_MCMETA_BAD", Level.PARTIAL, "pack.mcmeta unreadable", "pack.mcmeta")

    mixins = meta.get("fabric", {}).get("mixins", []) if "fabric" in meta else []
    rep.data["mixin_configs"] = mixins
    if api["mixin"]:
        rep.add("USES_MIXIN", Level.INFO, "uses Mixin: patches vanilla internals; breaks across MC versions")
    if bad:
        rep.add("CLASS_ERRORS", Level.PARTIAL, f"{bad} class file(s) could not be parsed")
    return rep


def _fabric(z, rep) -> dict[str, Any]:
    try:
        d = json.loads(_read(z, "fabric.mod.json"))
    except json.JSONDecodeError as e:
        rep.add("FABRIC_META_BAD", Level.PARTIAL, f"fabric.mod.json invalid: {e}", "fabric.mod.json")
        return {}
    mixins = []
    for m in d.get("mixins", []):
        mixins.append(m if isinstance(m, str) else m.get("config"))
    return {"id": d.get("id"), "version": d.get("version"), "depends": d.get("depends", {}),
            "environment": d.get("environment"), "entrypoints": d.get("entrypoints", {}),
            "mixins": [m for m in mixins if m]}


def _toml(z, name, rep) -> dict[str, Any]:
    try:
        return tomllib.loads(_read(z, name).decode("utf-8"))
    except (tomllib.TOMLDecodeError, UnicodeDecodeError) as e:
        rep.add("TOML_BAD", Level.PARTIAL, f"{name} invalid: {e}", name)
        return {}


def _mcmod_info(z, rep) -> dict[str, Any]:
    try:
        d = loads_jsonc(_read(z, "mcmod.info"))
    except MalformedInput as e:
        rep.add("MCMOD_BAD", Level.PARTIAL, str(e), "mcmod.info")
        return {}
    mods = d.get("modList", []) if isinstance(d, dict) else d
    first = mods[0] if mods and isinstance(mods[0], dict) else {}
    return {"modid": first.get("modid"), "version": first.get("version"),
            "mcversion": first.get("mcversion"), "name": first.get("name"),
            "description": first.get("description"), "authorList": first.get("authorList", [])}


def _mc_hint(meta: dict[str, Any]) -> str | None:
    cands: list[str] = []
    if "forge-legacy" in meta and meta["forge-legacy"].get("mcversion"):
        cands.append(str(meta["forge-legacy"]["mcversion"]))
    if "fabric" in meta:
        v = meta["fabric"].get("depends", {}).get("minecraft")
        cands.extend(v if isinstance(v, list) else [v] if v else [])
    for key in ("forge", "neoforge"):
        for deps in meta.get(key, {}).get("dependencies", {}).values():
            for d in deps:
                if d.get("modId") == "minecraft" and d.get("versionRange"):
                    cands.append(d["versionRange"])
    for c in cands:
        m = _VER.search(str(c))
        if m:
            return m.group(0)
    return None


def _resources(names: list[str]) -> dict[str, Any]:
    ns_assets: Counter[str] = Counter()
    ns_data: Counter[str] = Counter()
    kinds: Counter[str] = Counter()
    for n in names:
        parts = n.split("/")
        if parts[0] == "assets" and len(parts) > 3:
            ns_assets[parts[1]] += 1
            kinds[parts[2]] += 1
        elif parts[0] == "data" and len(parts) > 3:
            ns_data[parts[1]] += 1
            kinds["data:" + parts[2]] += 1
    return {"asset_namespaces": dict(ns_assets), "data_namespaces": dict(ns_data), "kinds": dict(kinds)}
