"""Minimal, strict JVM class-file parser (JVMS chapter 4).

Parses the constant pool, header, interfaces, fields and methods. Attributes are
skipped (but bounds-checked). That is enough to see every class, member and string
a class references, which is what the analyzers need. It never executes code.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field

from ..core.errors import MalformedInput

MAGIC = 0xCAFEBABE


@dataclass
class MemberRef:
    owner: str
    name: str
    descriptor: str
    kind: str  # field | method | imethod


@dataclass
class ClassInfo:
    major: int
    minor: int
    name: str
    super_name: str | None
    interfaces: list[str]
    access: int
    fields: list[tuple[str, str]]
    methods: list[tuple[str, str]]
    class_refs: set[str] = field(default_factory=set)
    member_refs: list[MemberRef] = field(default_factory=list)
    utf8: set[str] = field(default_factory=set)

    @property
    def java_version(self) -> int:
        return self.major - 44


class _Reader:
    def __init__(self, data: bytes):
        self.d, self.p = data, 0

    def take(self, n: int) -> bytes:
        if n < 0 or self.p + n > len(self.d):
            raise MalformedInput("class file truncated")
        s = self.d[self.p:self.p + n]
        self.p += n
        return s

    def u1(self) -> int:
        return self.take(1)[0]

    def u2(self) -> int:
        return struct.unpack(">H", self.take(2))[0]

    def u4(self) -> int:
        return struct.unpack(">I", self.take(4))[0]


def _mutf8(b: bytes) -> str:
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("utf-8", "replace")  # modified UTF-8 edge cases (surrogates, NUL)


def parse_class(data: bytes) -> ClassInfo:
    r = _Reader(data)
    if r.u4() != MAGIC:
        raise MalformedInput("bad class magic")
    minor, major = r.u2(), r.u2()
    if not 45 <= major <= 120:
        raise MalformedInput(f"implausible class major version {major}")
    count = r.u2()
    pool: list[tuple | None] = [None] * count
    i = 1
    while i < count:
        tag = r.u1()
        if tag == 1:
            pool[i] = ("utf8", _mutf8(r.take(r.u2())))
        elif tag in (3, 4):
            r.take(4)
            pool[i] = ("num",)
        elif tag in (5, 6):
            r.take(8)
            pool[i] = ("num",)
            i += 1  # long/double take two slots
        elif tag == 7:
            pool[i] = ("class", r.u2())
        elif tag in (8, 16, 19, 20):
            r.u2()
            pool[i] = ("str",)
        elif tag in (9, 10, 11):
            pool[i] = ({9: "field", 10: "method", 11: "imethod"}[tag], r.u2(), r.u2())
        elif tag == 12:
            pool[i] = ("nat", r.u2(), r.u2())
        elif tag == 15:
            r.take(3)
            pool[i] = ("mh",)
        elif tag in (17, 18):
            r.take(4)
            pool[i] = ("dyn",)
        else:
            raise MalformedInput(f"unknown constant pool tag {tag}")
        i += 1

    def utf(idx: int) -> str:
        e = pool[idx] if 0 < idx < count else None
        if not e or e[0] != "utf8":
            raise MalformedInput(f"constant {idx} is not Utf8")
        return e[1]

    def cname(idx: int) -> str:
        e = pool[idx] if 0 < idx < count else None
        if not e or e[0] != "class":
            raise MalformedInput(f"constant {idx} is not Class")
        return utf(e[1])

    access = r.u2()
    this = cname(r.u2())
    sup_idx = r.u2()
    sup = cname(sup_idx) if sup_idx else None
    interfaces = [cname(r.u2()) for _ in range(r.u2())]

    def members() -> list[tuple[str, str]]:
        out = []
        for _ in range(r.u2()):
            r.u2()
            name, desc = utf(r.u2()), utf(r.u2())
            for _ in range(r.u2()):
                r.u2()
                r.take(r.u4())
            out.append((name, desc))
        return out

    fields = members()
    methods = members()
    for _ in range(r.u2()):  # class attributes
        r.u2()
        r.take(r.u4())
    if r.p != len(data):
        raise MalformedInput("trailing bytes after class file")

    info = ClassInfo(major, minor, this, sup, interfaces, access, fields, methods)
    for e in pool:
        if not e:
            continue
        if e[0] == "utf8":
            info.utf8.add(e[1])
        elif e[0] == "class":
            n = utf(e[1])
            if n.startswith("["):  # array class: unwrap to the element type
                n = n.lstrip("[")
                n = n[1:-1] if n.startswith("L") and n.endswith(";") else ""
            if n:
                info.class_refs.add(n)
        elif e[0] in ("field", "method", "imethod"):
            nat = pool[e[2]]
            if not nat or nat[0] != "nat":
                raise MalformedInput("member ref without NameAndType")
            info.member_refs.append(MemberRef(cname(e[1]), utf(nat[1]), utf(nat[2]), e[0]))
    return info
