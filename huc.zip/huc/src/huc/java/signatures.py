"""Static knowledge used by the Java analyzer (data, not logic)."""
import re

# (label, internal-name prefix)
API_PREFIXES = [
    ("forge-legacy-fml", "cpw/mods/fml/"),
    ("forge", "net/minecraftforge/"),
    ("neoforge", "net/neoforged/"),
    ("fabric-api", "net/fabricmc/fabric/"),
    ("fabric-loader", "net/fabricmc/loader/"),
    ("quilt", "org/quiltmc/"),
    ("mixin", "org/spongepowered/asm/"),
    ("minecraft", "net/minecraft/"),
    ("mojang-libs", "com/mojang/"),
    ("lwjgl", "org/lwjgl/"),
]

# Mod entry annotations as they appear in the constant pool
MOD_ANNOTATIONS = {
    "Lnet/minecraftforge/fml/common/Mod;": "forge",   # 1.7-1.12 and 1.13+ share this descriptor
    "Lcpw/mods/fml/common/Mod;": "forge-legacy-fml",
    "Lnet/neoforged/fml/common/Mod;": "neoforge",
}

# Naming schemes visible in member/class names
RE_SRG = re.compile(r"^(func|field|p)_\d+_[A-Za-z_]+$")
RE_INTERMEDIARY = re.compile(r"^(method|field|class_)_?\d+$|^class_\d+$")
RE_NOTCH_CLASS = re.compile(r"^[a-z]{1,3}$")
