"""Version knowledge base.

Only values that were confidently known when this file was written are filled in.
Anything uncertain is ``None`` and ``verified=False`` -- the tools refuse to guess
and ask the user to supply the value (``--pack-format`` or a profile JSON).
Always double-check against the official Minecraft wiki before trusting a value
for production use.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

from ..core.errors import MissingProfile


@dataclass(frozen=True)
class VersionProfile:
    id: str
    java_major: int | None
    resource_pack_format: int | None
    data_pack_format: int | None
    flattened: bool  # True from 1.13 on (numeric IDs/metadata removed)
    verified: bool
    notes: str = ""


def _p(id, java, rp, dp, flat=True, verified=True, notes=""):
    return VersionProfile(id, java, rp, dp, flat, verified, notes)


PROFILES: dict[str, VersionProfile] = {p.id: p for p in [
    _p("1.12.2", 8, 3, None, flat=False, notes="Pre-flattening; Forge uses SRG names (func_/field_)."),
    _p("1.13.2", 8, 4, 4),
    _p("1.14.4", 8, 4, 4),
    _p("1.15.2", 8, 5, 5),
    _p("1.16.5", 8, 6, 6),
    _p("1.17.1", 16, 7, 7),
    _p("1.18.2", 17, 8, 8),
    _p("1.19.2", 17, 9, 10),
    _p("1.19.4", 17, 13, 12),
    _p("1.20.1", 17, 15, 15),
    _p("1.20.4", 17, 22, 26),
    _p("1.20.6", 21, 32, 41),
    _p("1.21.1", 21, 34, 48),
    _p("1.21.4", 21, 46, 61),
    # Newer / date-based releases: values NOT known here. Supply them explicitly.
    _p("26.1", None, None, None, verified=False, notes="Unknown to this table; supply a profile."),
    _p("26.2", None, None, None, verified=False, notes="Unknown to this table; supply a profile."),
    _p("26.3", None, None, None, verified=False, notes="Unknown to this table; supply a profile."),
]}


_VER = re.compile(r"\d+(?:\.\d+)*")


def parse_version(s: str) -> tuple[int, ...]:
    m = _VER.search(s)
    if not m:
        raise ValueError(f"not a version: {s!r}")
    return tuple(int(x) for x in m.group(0).split("."))


def get_profile(version: str) -> VersionProfile:
    """Return the known profile or an *unverified empty* one (never a guess)."""
    if version in PROFILES:
        return PROFILES[version]
    return VersionProfile(version, None, None, None, flattened=parse_version(version) >= (1, 13),
                          verified=False, notes="No profile for this version.")


def require_resource_pack_format(version: str, override: int | None = None) -> int:
    if override is not None:
        return override
    p = get_profile(version)
    if p.resource_pack_format is None:
        raise MissingProfile(
            f"resource pack_format for {version} is not known to HUC; "
            f"pass --pack-format N or load a profile with --target-profile")
    return p.resource_pack_format


@dataclass(frozen=True)
class TargetProfile:
    """Where a conversion should land: a loader on a Minecraft version, or Horizon."""
    id: str
    loader: str            # forge | neoforge | fabric | quilt | horizon | vanilla
    mc_version: str | None
    java_major: int | None = None
    resource_pack_format: int | None = None
    notes: str = ""

    @staticmethod
    def from_dict(d: dict) -> "TargetProfile":
        for k in ("id", "loader"):
            if k not in d:
                raise MissingProfile(f"target profile missing field {k!r}")
        return TargetProfile(d["id"], d["loader"], d.get("mc_version"), d.get("java_major"),
                             d.get("resource_pack_format"), d.get("notes", ""))

    @staticmethod
    def from_file(path: str) -> "TargetProfile":
        with open(path, encoding="utf-8") as f:
            return TargetProfile.from_dict(json.load(f))

    @staticmethod
    def for_loader(loader: str, mc_version: str) -> "TargetProfile":
        vp = get_profile(mc_version)
        return TargetProfile(f"{loader}-{mc_version}", loader, mc_version, vp.java_major,
                             vp.resource_pack_format, vp.notes)
