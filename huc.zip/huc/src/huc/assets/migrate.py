"""Resource migration for pre-flattening (1.12.x style) mod assets -> 1.13+ layout.

What is converted automatically (each rule has tests):
  * textures/blocks -> textures/block, textures/items -> textures/item
  * model JSON texture references ("blocks/x" -> "block/x", "items/x" -> "item/x")
  * blockstate variant key "normal" -> ""
  * .lang files -> .json language files
  * assets/<ns>/{recipes,advancements,loot_tables} -> data/<ns>/...
  * shaped/shapeless recipes whose ingredients/results have metadata 0
  * pack.mcmeta pack_format rewritten to the target value
  * upper-case file paths lower-cased (illegal in 1.13+)

What is only REPORTED (needs a human; never silently altered):
  * Forge blockstate format ("forge_marker"), non-zero item metadata, forge:* recipe types,
    anything else with a pre-1.13 schema we do not have a rule for,
    recipe/loot/advancement schema drift introduced after 1.13 (see 'schema_drift' finding).

Honest limit: rules are verified against synthetic fixtures built from the documented
formats, NOT against a running game. Treat output as a head start, then load it in-game.
"""
from __future__ import annotations

import io
import json
import os
import re
import zipfile
from dataclasses import dataclass, field

from ..core.errors import MalformedInput
from ..core.jsonc import loads_jsonc
from ..core.report import Level, Report
from ..java.analyzer import MAX_ENTRY, open_zip_safely

_MOVED_DATA = ("recipes", "advancements", "loot_tables", "structures")
_TEXTURE_FIX = (("blocks/", "block/"), ("items/", "item/"))


@dataclass
class MigrationResult:
    files: dict[str, bytes] = field(default_factory=dict)  # output path -> bytes
    report: Report = field(default_factory=lambda: Report("assets", "asset-migration"))

    def write_to(self, out_dir: str) -> None:
        root = os.path.abspath(out_dir)
        for rel, data in self.files.items():
            dest = os.path.abspath(os.path.join(root, rel))
            if not dest.startswith(root + os.sep):
                raise MalformedInput(f"refusing to write outside output dir: {rel}")
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with open(dest, "wb") as f:
                f.write(data)

    def to_zip(self) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for rel in sorted(self.files):
                z.writestr(rel, self.files[rel])
        return buf.getvalue()


def load_tree(src: str) -> dict[str, bytes]:
    """Read a directory or zip/jar into {relative/posix/path: bytes} with safety limits."""
    files: dict[str, bytes] = {}
    if os.path.isdir(src):
        for root, _d, fs in os.walk(src):
            for f in fs:
                p = os.path.join(root, f)
                rel = os.path.relpath(p, src).replace(os.sep, "/")
                if os.path.getsize(p) > MAX_ENTRY:
                    raise MalformedInput(f"{rel}: file too large")
                with open(p, "rb") as fh:
                    files[rel] = fh.read()
        return files
    z = open_zip_safely(src)
    for info in z.infolist():
        if info.is_dir() or info.filename.endswith("/"):
            continue
        parts = info.filename.split("/")
        if info.filename.startswith("/") or ".." in parts:
            raise MalformedInput(f"unsafe path in archive: {info.filename!r}")
        if info.file_size > MAX_ENTRY:
            raise MalformedInput(f"{info.filename}: entry too large")
        files[info.filename] = z.read(info)
    return files


def _fix_tex_ref(ref: str) -> str:
    ns, sep, path = ref.partition(":") if ":" in ref else ("", "", ref)
    for old, new in _TEXTURE_FIX:
        if path.startswith(old):
            path = new + path[len(old):]
            break
    return (ns + sep + path).lower()


def parse_lang(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def _strip_data0(obj, rep: Report, path: str) -> bool:
    """Remove metadata 0 from an ingredient/result; return False if non-zero metadata found."""
    if isinstance(obj, list):
        return all(_strip_data0(o, rep, path) for o in obj)
    if isinstance(obj, dict) and "data" in obj:
        if obj["data"] not in (0, None):
            rep.add("RECIPE_METADATA", Level.MANUAL,
                    f"item {obj.get('item')} uses metadata {obj['data']}: flattening gave it a new id; map it by hand", path)
            return False
        del obj["data"]
    return True


def migrate_assets(src: str, target_mc_version: str, pack_format: int | None = None) -> MigrationResult:
    from ..knowledge.versions import get_profile, require_resource_pack_format

    res = MigrationResult()
    rep = res.report
    rep.subject = src
    fmt = require_resource_pack_format(target_mc_version, pack_format)
    rep.data["target"] = target_mc_version
    rep.data["pack_format"] = fmt
    tree = load_tree(src)
    counts = {"copied": 0, "moved": 0, "converted": 0}

    for path, data in sorted(tree.items()):
        parts = path.split("/")
        new_path = path
        out_data = data

        if path == "pack.mcmeta":
            try:
                d = loads_jsonc(data)
                d.setdefault("pack", {})["pack_format"] = fmt
                out_data = json.dumps(d, indent=2).encode()
                counts["converted"] += 1
            except (MalformedInput, AttributeError):
                rep.add("PACK_MCMETA_BAD", Level.MANUAL, "pack.mcmeta is not valid; write a new one", path)
        elif len(parts) >= 4 and parts[0] == "assets":
            ns, kind, rest = parts[1], parts[2], "/".join(parts[3:])
            if kind == "textures" and parts[3] in ("blocks", "items"):
                new_path = f"assets/{ns}/textures/{parts[3][:-1]}/" + "/".join(parts[4:])
                counts["moved"] += 1
            elif kind == "lang" and path.endswith(".lang"):
                name = parts[-1][:-5].lower()
                new_path = f"assets/{ns}/lang/{name}.json"
                out_data = json.dumps(parse_lang(data.decode("utf-8", "replace")), indent=2,
                                      ensure_ascii=False).encode()
                counts["converted"] += 1
            elif kind in _MOVED_DATA:
                new_path = f"data/{ns}/{kind}/{rest}"
                counts["moved"] += 1
                if kind == "recipes" and path.endswith(".json"):
                    out_data = _migrate_recipe(data, path, rep)
            elif kind == "models" and path.endswith(".json"):
                out_data = _migrate_model(data, path, rep)
                counts["converted"] += 1
            elif kind == "blockstates" and path.endswith(".json"):
                out_data = _migrate_blockstate(data, path, rep)
                counts["converted"] += 1
        low = new_path.lower()
        if low != new_path and new_path.startswith(("assets/", "data/")):
            rep.add("PATH_LOWERCASED", Level.AUTO, f"{new_path} -> {low} (1.13+ requires lower-case ids)", path)
            new_path = low
        if new_path in res.files and res.files[new_path] != out_data:
            rep.add("PATH_COLLISION", Level.MANUAL, f"two sources map to {new_path}", path)
            continue
        res.files[new_path] = out_data
        counts["copied"] += 1

    rep.data["counts"] = counts
    profile = get_profile(target_mc_version)
    if not profile.verified or profile.resource_pack_format is None or (profile.resource_pack_format or 0) > 4:
        rep.add("SCHEMA_DRIFT", Level.PARTIAL,
                f"data/asset JSON schemas changed again after 1.13 (recipes, loot tables, item models, "
                f"directory names). HUC only applies 1.12->1.13 rules; target {target_mc_version} needs "
                f"further manual or rule-based migration.")
    rep.add("MIGRATED", Level.AUTO if not (rep.count(Level.MANUAL)) else Level.PARTIAL,
            f"{counts['copied']} files written ({counts['moved']} moved, {counts['converted']} rewritten)")
    return res


def _migrate_model(data: bytes, path: str, rep: Report) -> bytes:
    try:
        d = loads_jsonc(data)
    except MalformedInput as e:
        rep.add("MODEL_BAD_JSON", Level.MANUAL, str(e), path)
        return data
    if not isinstance(d, dict):
        return data
    if isinstance(d.get("textures"), dict):
        d["textures"] = {k: (_fix_tex_ref(v) if isinstance(v, str) and not v.startswith("#") else v)
                         for k, v in d["textures"].items()}
    if isinstance(d.get("parent"), str):
        d["parent"] = d["parent"].lower()
    return json.dumps(d, indent=2).encode()


def _migrate_blockstate(data: bytes, path: str, rep: Report) -> bytes:
    try:
        d = loads_jsonc(data)
    except MalformedInput as e:
        rep.add("BLOCKSTATE_BAD_JSON", Level.MANUAL, str(e), path)
        return data
    if isinstance(d, dict) and "forge_marker" in d:
        rep.add("FORGE_BLOCKSTATE", Level.MANUAL,
                "Forge blockstate format (forge_marker) has no vanilla equivalent; rebuild", path)
        return data
    if isinstance(d, dict) and isinstance(d.get("variants"), dict) and "normal" in d["variants"]:
        d["variants"][""] = d["variants"].pop("normal")
        rep.add("BLOCKSTATE_NORMAL", Level.AUTO, 'variant "normal" renamed to ""', path)
    if isinstance(d, dict) and isinstance(d.get("variants"), dict):
        rep.add("BLOCKSTATE_PROPS", Level.INFO,
                "variant keys must still match the block's properties in the new version; verify in code", path)
    return json.dumps(d, indent=2).encode()


def _migrate_recipe(data: bytes, path: str, rep: Report) -> bytes:
    try:
        d = loads_jsonc(data)
    except MalformedInput as e:
        rep.add("RECIPE_BAD_JSON", Level.MANUAL, str(e), path)
        return data
    t = d.get("type", "") if isinstance(d, dict) else ""
    if t.startswith("forge:"):
        rep.add("RECIPE_FORGE_TYPE", Level.MANUAL, f"recipe type {t} needs a custom/conditional rewrite", path)
        return data
    if t not in ("minecraft:crafting_shaped", "minecraft:crafting_shapeless", "crafting_shaped", "crafting_shapeless"):
        rep.add("RECIPE_UNHANDLED_TYPE", Level.MANUAL, f"no migration rule for recipe type {t!r}", path)
        return data
    ok = True
    if "key" in d:
        ok &= all(_strip_data0(v, rep, path) for v in d["key"].values())
    if "ingredients" in d:
        ok &= _strip_data0(d["ingredients"], rep, path)
    if "result" in d:
        ok &= _strip_data0(d["result"], rep, path)
    if not ok:
        return data
    rep.add("RECIPE_OK", Level.AUTO, "metadata-0 recipe converted", path)
    return json.dumps(d, indent=2).encode()
