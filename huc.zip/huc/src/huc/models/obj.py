"""Wavefront OBJ importer/exporter."""
from __future__ import annotations

from ..core.errors import MalformedInput
from .ir import Material, Mesh, Model


def _resolve(idx: int, n: int, line_no: int) -> int:
    i = idx - 1 if idx > 0 else n + idx
    if not (0 <= i < n):
        raise MalformedInput(f"OBJ line {line_no}: index {idx} out of range")
    return i


def parse_obj(text: str, name: str = "model") -> Model:
    model = Model(name=name, meta={"source_format": "obj"})
    v: list[tuple[float, float, float]] = []
    vt: list[tuple[float, float]] = []
    vn: list[tuple[float, float, float]] = []
    mat_idx: dict[str, int] = {}
    cur_obj, cur_mat = name, -1
    cur: Mesh | None = None
    cache: dict[tuple[int, int, int], int] = {}
    vert_has_uv: list[bool] = []
    vert_has_n: list[bool] = []

    def finish() -> None:
        nonlocal cur
        if cur is not None and cur.indices:
            if not any(vert_has_uv):
                cur.uvs = []
            if not any(vert_has_n):
                cur.normals = []
            model.meshes.append(cur)
        cur = None

    for line_no, raw in enumerate(text.splitlines(), 1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        key, args = parts[0], parts[1:]
        try:
            if key == "v":
                v.append((float(args[0]), float(args[1]), float(args[2])))
            elif key == "vt":
                vt.append((float(args[0]), float(args[1]) if len(args) > 1 else 0.0))
            elif key == "vn":
                vn.append((float(args[0]), float(args[1]), float(args[2])))
            elif key in ("o", "g"):
                finish()
                cur_obj = " ".join(args) or name
            elif key == "usemtl":
                finish()
                mname = " ".join(args)
                if mname not in mat_idx:
                    mat_idx[mname] = len(model.materials)
                    model.materials.append(Material(mname))
                cur_mat = mat_idx[mname]
            elif key == "mtllib":
                model.meta.setdefault("mtllib", []).append(" ".join(args))
            elif key == "f":
                if len(args) < 3:
                    model.warnings.append(f"line {line_no}: face with <3 vertices skipped")
                    continue
                if cur is None:
                    cur = Mesh(name=cur_obj, material=cur_mat)
                    cache, vert_has_uv, vert_has_n = {}, [], []
                face: list[int] = []
                for tok in args:
                    f = tok.split("/")
                    vi = _resolve(int(f[0]), len(v), line_no)
                    ti = _resolve(int(f[1]), len(vt), line_no) if len(f) > 1 and f[1] else -1
                    ni = _resolve(int(f[2]), len(vn), line_no) if len(f) > 2 and f[2] else -1
                    k = (vi, ti, ni)
                    if k not in cache:
                        cache[k] = cur.vertex_count
                        cur.positions.extend(v[vi])
                        cur.uvs.extend((vt[ti][0], 1.0 - vt[ti][1]) if ti >= 0 else (0.0, 0.0))
                        cur.normals.extend(vn[ni] if ni >= 0 else (0.0, 0.0, 0.0))
                        vert_has_uv.append(ti >= 0)
                        vert_has_n.append(ni >= 0)
                    face.append(cache[k])
                for i in range(1, len(face) - 1):  # fan triangulation (convex polygons)
                    cur.indices.extend((face[0], face[i], face[i + 1]))
        except (ValueError, IndexError) as e:
            raise MalformedInput(f"OBJ line {line_no}: {e}") from e
    finish()
    # de-duplicate mesh names
    seen: dict[str, int] = {}
    for m in model.meshes:
        n = seen.get(m.name, 0)
        seen[m.name] = n + 1
        if n:
            m.name = f"{m.name}.{n}"
    model.validate()
    return model


def write_obj(model: Model, mtl_name: str | None = None) -> str:
    """Write meshes (cubes must be tessellated first, see hurm.exporters)."""
    out = ["# written by HUC"]
    if mtl_name:
        out.append(f"mtllib {mtl_name}")
    base = 1
    for m in model.meshes:
        out.append(f"o {m.name}")
        if m.material >= 0:
            out.append(f"usemtl {model.materials[m.material].name}")
        for i in range(0, len(m.positions), 3):
            out.append("v %.9g %.9g %.9g" % tuple(m.positions[i:i + 3]))
        has_uv, has_n = bool(m.uvs), bool(m.normals)
        for i in range(0, len(m.uvs), 2):
            out.append("vt %.9g %.9g" % (m.uvs[i], 1.0 - m.uvs[i + 1]))
        for i in range(0, len(m.normals), 3):
            out.append("vn %.9g %.9g %.9g" % tuple(m.normals[i:i + 3]))
        for i in range(0, len(m.indices), 3):
            refs = []
            for j in m.indices[i:i + 3]:
                n = base + j
                refs.append(f"{n}/{n}/{n}" if has_uv and has_n else f"{n}/{n}" if has_uv
                            else f"{n}//{n}" if has_n else f"{n}")
            out.append("f " + " ".join(refs))
        base += m.vertex_count
    return "\n".join(out) + "\n"
