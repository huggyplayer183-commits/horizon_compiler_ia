"""Intermediate representation shared by every model importer/exporter.

Conventions (fixed, documented in docs/HURM_SPEC.md):
* right-handed, +Y up, counter-clockwise front faces
* UV origin is TOP-LEFT (v grows downward) - same as glTF, Blockbench and Minecraft
* a Model holds triangle meshes and/or axis-aligned *cubes* (Minecraft box models)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.errors import MalformedInput

FACES = ("north", "east", "south", "west", "up", "down")


@dataclass
class Texture:
    name: str
    data: bytes = b""  # PNG bytes (may be empty if only referenced by name)


@dataclass
class Material:
    name: str
    texture: int = -1  # index into Model.textures, -1 = none


@dataclass
class Mesh:
    name: str
    positions: list[float] = field(default_factory=list)  # xyz flat
    normals: list[float] = field(default_factory=list)    # xyz flat, or empty
    uvs: list[float] = field(default_factory=list)        # uv flat, or empty
    indices: list[int] = field(default_factory=list)      # triangles
    material: int = -1

    @property
    def vertex_count(self) -> int:
        return len(self.positions) // 3

    def validate(self) -> None:
        vc = self.vertex_count
        if len(self.positions) % 3:
            raise MalformedInput(f"mesh {self.name!r}: positions length not multiple of 3")
        if self.normals and len(self.normals) != len(self.positions):
            raise MalformedInput(f"mesh {self.name!r}: normals/positions size mismatch")
        if self.uvs and len(self.uvs) != vc * 2:
            raise MalformedInput(f"mesh {self.name!r}: uvs/positions size mismatch")
        if len(self.indices) % 3:
            raise MalformedInput(f"mesh {self.name!r}: index count not multiple of 3")
        if self.indices and (min(self.indices) < 0 or max(self.indices) >= vc):
            raise MalformedInput(f"mesh {self.name!r}: index out of range")


@dataclass
class Cube:
    name: str
    from_: list[float]
    to: list[float]
    origin: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])    # rotation pivot
    rotation: list[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])  # degrees xyz
    faces: dict[str, dict[str, Any]] = field(default_factory=dict)          # face -> {uv:[4], texture:int, rotation:int}

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "from": self.from_, "to": self.to, "origin": self.origin,
                "rotation": self.rotation, "faces": self.faces}

    @staticmethod
    def from_dict(d: dict[str, Any]) -> "Cube":
        try:
            return Cube(d["name"], [float(x) for x in d["from"]], [float(x) for x in d["to"]],
                        [float(x) for x in d.get("origin", [0, 0, 0])],
                        [float(x) for x in d.get("rotation", [0, 0, 0])], dict(d.get("faces", {})))
        except (KeyError, TypeError, ValueError) as e:
            raise MalformedInput(f"bad cube record: {e}") from e


@dataclass
class Model:
    name: str
    meshes: list[Mesh] = field(default_factory=list)
    cubes: list[Cube] = field(default_factory=list)
    materials: list[Material] = field(default_factory=list)
    textures: list[Texture] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def warnings(self) -> list[str]:
        return self.meta.setdefault("warnings", [])

    def validate(self) -> None:
        for m in self.meshes:
            m.validate()
            if m.material >= len(self.materials):
                raise MalformedInput(f"mesh {m.name!r}: material index out of range")
        for mat in self.materials:
            if mat.texture >= len(self.textures):
                raise MalformedInput(f"material {mat.name!r}: texture index out of range")
        for c in self.cubes:
            for f, fd in c.faces.items():
                if f not in FACES:
                    raise MalformedInput(f"cube {c.name!r}: unknown face {f!r}")
                t = fd.get("texture")
                if t is not None and not (0 <= t < len(self.textures)):
                    raise MalformedInput(f"cube {c.name!r}: texture index out of range")
