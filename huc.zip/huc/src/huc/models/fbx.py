"""Binary FBX geometry importer (versions 7100-7700).

Reads Geometry/Mesh nodes: vertices, polygons (triangulated by fan),
normals and UVs with ByPolygonVertex mapping (Direct / IndexToDirect) or
ByVertice mapping. Node transforms (Model/connections), materials, skeletons
and animation are NOT read; ASCII FBX is rejected explicitly.
"""
from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass, field
from typing import Any

from ..core.errors import MalformedInput, UnsupportedFormat
from .ir import Mesh, Model

MAGIC = b"Kaydara FBX Binary  \x00\x1a\x00"
_MAX_DEPTH = 64
_MAX_ARRAY = 1 << 28


@dataclass
class Node:
    name: str
    props: list[Any] = field(default_factory=list)
    children: list["Node"] = field(default_factory=list)

    def child(self, name: str) -> "Node | None":
        return next((c for c in self.children if c.name == name), None)

    def all(self, name: str) -> list["Node"]:
        return [c for c in self.children if c.name == name]


class _R:
    def __init__(self, b: bytes):
        self.b, self.p = b, 0

    def take(self, n: int) -> bytes:
        if n < 0 or self.p + n > len(self.b):
            raise MalformedInput("FBX truncated")
        s = self.b[self.p:self.p + n]
        self.p += n
        return s

    def u(self, fmt: str):
        size = struct.calcsize(fmt)
        return struct.unpack("<" + fmt, self.take(size))[0]


_SCALAR = {"Y": "h", "C": "?", "I": "i", "F": "f", "D": "d", "L": "q"}
_ARRAY = {"f": "f", "d": "d", "l": "q", "i": "i", "b": "?"}


def _prop(r: _R):
    t = chr(r.u("B"))
    if t in _SCALAR:
        return r.u(_SCALAR[t])
    if t in _ARRAY:
        n, enc, clen = r.u("I"), r.u("I"), r.u("I")
        if n > _MAX_ARRAY:
            raise MalformedInput("FBX array too large")
        raw = r.take(clen)
        if enc == 1:
            try:
                raw = zlib.decompress(raw)
            except zlib.error as e:
                raise MalformedInput(f"FBX array zlib error: {e}") from e
        elif enc != 0:
            raise MalformedInput(f"unknown FBX array encoding {enc}")
        fmt = _ARRAY[t]
        if len(raw) != n * struct.calcsize(fmt):
            raise MalformedInput("FBX array size mismatch")
        return list(struct.unpack(f"<{n}{fmt}", raw))
    if t == "S":
        return r.take(r.u("I")).decode("utf-8", "replace")
    if t == "R":
        return r.take(r.u("I"))
    raise MalformedInput(f"unknown FBX property type {t!r}")


def _node(r: _R, ver: int, depth: int) -> Node | None:
    if depth > _MAX_DEPTH:
        raise MalformedInput("FBX nesting too deep")
    big = ver >= 7500
    end = r.u("Q" if big else "I")
    nprops = r.u("Q" if big else "I")
    r.u("Q" if big else "I")  # property list length
    nlen = r.u("B")
    if end == 0:
        return None
    node = Node(r.take(nlen).decode("utf-8", "replace"))
    for _ in range(nprops):
        node.props.append(_prop(r))
    while r.p < end:
        c = _node(r, ver, depth + 1)
        if c is None:
            break
        node.children.append(c)
    if r.p != end:
        raise MalformedInput("FBX node end offset mismatch")
    return node


def parse_fbx_tree(data: bytes) -> tuple[int, list[Node]]:
    if data[:21] != MAGIC[:21]:
        if data[:20].startswith(b"; FBX") or data.lstrip()[:5] == b"; FBX":
            raise UnsupportedFormat("ASCII FBX is not supported; export binary FBX")
        raise MalformedInput("not an FBX file")
    r = _R(data)
    r.p = 23
    ver = r.u("I")
    if not 7000 <= ver <= 7800:
        raise UnsupportedFormat(f"FBX version {ver}")
    nodes = []
    while r.p < len(data):
        n = _node(r, ver, 0)
        if n is None:
            break
        nodes.append(n)
    return ver, nodes


def parse_fbx(data: bytes, name: str = "model") -> Model:
    ver, top = parse_fbx_tree(data)
    model = Model(name=name, meta={"source_format": "fbx", "fbx_version": ver})
    objects = next((n for n in top if n.name == "Objects"), None)
    if objects is None:
        raise MalformedInput("FBX has no Objects node")
    model.warnings.append("node transforms, materials and textures are not read from FBX")
    for geo in objects.all("Geometry"):
        if len(geo.props) < 3 or geo.props[2] != "Mesh":
            continue
        gname = str(geo.props[1]).split("\x00")[0] or "geometry"
        verts = (geo.child("Vertices") or Node("")).props
        pvi = (geo.child("PolygonVertexIndex") or Node("")).props
        if not verts or not pvi:
            continue
        verts, pvi = verts[0], pvi[0]
        if len(verts) % 3:
            raise MalformedInput(f"{gname}: Vertices not multiple of 3")
        # split polygons: last index of each polygon is stored as ~idx (negative)
        polys, cur = [], []
        for v in pvi:
            if v < 0:
                cur.append(~v)
                polys.append(cur)
                cur = []
            else:
                cur.append(v)
        if cur:
            raise MalformedInput(f"{gname}: unterminated polygon")
        nverts = len(verts) // 3
        slots = [i for p in polys for i in p]
        normals = _layer(geo, "LayerElementNormal", "Normals", "NormalsIndex", 3, len(slots), nverts, slots, model)
        uvs = _layer(geo, "LayerElementUV", "UV", "UVIndex", 2, len(slots), nverts, slots, model)
        mesh = Mesh(name=gname)
        slot = 0
        for p in polys:
            base = mesh.vertex_count
            for vi in p:
                if not 0 <= vi < nverts:
                    raise MalformedInput(f"{gname}: vertex index out of range")
                mesh.positions.extend(verts[vi * 3: vi * 3 + 3])
                if normals is not None:
                    mesh.normals.extend(normals[slot])
                if uvs is not None:
                    u, v = uvs[slot]
                    mesh.uvs.extend((u, 1.0 - v))  # FBX UV origin is bottom-left
                slot += 1
            for i in range(1, len(p) - 1):
                mesh.indices.extend((base, base + i, base + i + 1))
        if mesh.indices:
            model.meshes.append(mesh)
    if not model.meshes:
        raise MalformedInput("FBX contains no mesh geometry")
    model.validate()
    return model


def _layer(geo: Node, lname: str, dname: str, iname: str, width: int, nslots: int,
           nverts: int, slots: list[int], model: Model):
    layer = geo.child(lname)
    if layer is None:
        return None
    data = (layer.child(dname) or Node("")).props
    if not data:
        return None
    data = data[0]
    mapping = (layer.child("MappingInformationType") or Node("", [""])).props[0]
    ref = (layer.child("ReferenceInformationType") or Node("", [""])).props[0]
    idx_node = layer.child(iname)
    groups = [tuple(data[i:i + width]) for i in range(0, len(data) - width + 1, width)]
    if mapping == "ByPolygonVertex":
        if ref == "IndexToDirect" and idx_node and idx_node.props:
            idx = idx_node.props[0]
            if len(idx) != nslots or (idx and max(idx) >= len(groups)):
                raise MalformedInput(f"{lname}: bad index array")
            return [groups[i] if i >= 0 else (0.0,) * width for i in idx]
        if ref == "Direct" and len(groups) == nslots:
            return groups
    elif mapping == "ByVertice" and len(groups) == nverts:
        return [groups[i] for i in slots]
    model.warnings.append(f"{lname}: mapping {mapping}/{ref} not supported; layer dropped")
    return None
