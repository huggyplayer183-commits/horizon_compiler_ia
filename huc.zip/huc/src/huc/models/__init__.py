"""3D model importers. ``load_model`` dispatches by extension."""
from __future__ import annotations

import os

from ..core.errors import UnsupportedFormat
from .ir import Model


def load_model(path: str) -> Model:
    ext = os.path.splitext(path)[1].lower()
    name = os.path.splitext(os.path.basename(path))[0]
    with open(path, "rb") as f:
        data = f.read()
    if ext == ".obj":
        from .obj import parse_obj
        return parse_obj(data.decode("utf-8", "replace"), name)
    if ext in (".gltf", ".glb"):
        from .gltf import parse_gltf
        return parse_gltf(data, os.path.dirname(os.path.abspath(path)), name)
    if ext == ".bbmodel":
        from .bbmodel import parse_bbmodel
        return parse_bbmodel(data, name)
    if ext == ".fbx":
        from .fbx import parse_fbx
        return parse_fbx(data, name)
    if ext == ".hurm":
        from ..hurm.format import read_hurm
        return read_hurm(data)
    raise UnsupportedFormat(f"unsupported model extension {ext!r}")
