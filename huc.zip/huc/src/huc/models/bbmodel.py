"""Blockbench .bbmodel importer.

Supported: cube elements (explicit per-face UVs, inflate), mesh elements
(triangulated, origin offset), embedded PNG textures.
Reported, not converted: box-UV cubes, group/bone rotations, mesh rotations,
animations, locators.
"""
from __future__ import annotations

import base64
import json
from typing import Any

from ..core.errors import MalformedInput
from .ir import FACES, Cube, Material, Mesh, Model, Texture


def _nonzero(v) -> bool:
    return bool(v) and any(abs(float(x)) > 1e-9 for x in v)


def _walk_groups(outliner: list, found: list[str]) -> None:
    for item in outliner:
        if isinstance(item, dict):
            if _nonzero(item.get("rotation")):
                found.append(item.get("name", "?"))
            _walk_groups(item.get("children", []), found)


def parse_bbmodel(data: bytes | str, name: str | None = None) -> Model:
    try:
        d = json.loads(data if isinstance(data, str) else data.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise MalformedInput(f"not valid bbmodel JSON: {e}") from e
    if not isinstance(d, dict) or "elements" not in d and "meta" not in d:
        raise MalformedInput("missing 'elements'/'meta' - not a bbmodel")

    res = d.get("resolution") or {}
    rw, rh = float(res.get("width", 16)), float(res.get("height", 16))
    model = Model(name=name or d.get("name", "model"),
                  meta={"source_format": "bbmodel", "resolution": [rw, rh], "unit_scale": 16,
                        "bbmodel_format": d.get("meta", {}).get("model_format")})

    for i, t in enumerate(d.get("textures", [])):
        src = t.get("source", "")
        png = b""
        if src.startswith("data:") and "," in src:
            try:
                png = base64.b64decode(src.split(",", 1)[1])
            except Exception as e:  # noqa: BLE001
                raise MalformedInput(f"texture {i}: bad base64") from e
        model.textures.append(Texture(t.get("name", f"texture{i}"), png))
        model.materials.append(Material(t.get("name", f"texture{i}"), i))

    groups: list[str] = []
    _walk_groups(d.get("outliner", []), groups)
    if groups:
        model.warnings.append("group rotations are not baked into cubes: " + ", ".join(groups))
    if d.get("animations"):
        model.warnings.append("animations ignored")

    for el in d.get("elements", []):
        kind = el.get("type", "cube")
        ename = el.get("name", "element")
        if kind == "cube":
            if el.get("box_uv"):
                model.warnings.append(f"cube {ename!r} uses box UV: faces left empty (unsupported)")
                faces: dict[str, Any] = {}
            else:
                faces = {}
                for f in FACES:
                    fd = (el.get("faces") or {}).get(f)
                    if fd and fd.get("texture") is not None and len(fd.get("uv", [])) == 4:
                        entry = {"uv": [float(x) for x in fd["uv"]], "texture": int(fd["texture"])}
                        if fd.get("rotation"):
                            entry["rotation"] = int(fd["rotation"])
                        faces[f] = entry
            inf = float(el.get("inflate", 0) or 0)
            try:
                frm = [float(x) - inf for x in el["from"]]
                to = [float(x) + inf for x in el["to"]]
            except (KeyError, TypeError, ValueError) as e:
                raise MalformedInput(f"cube {ename!r}: bad from/to") from e
            if len(frm) != 3 or len(to) != 3:
                raise MalformedInput(f"cube {ename!r}: from/to must have 3 values")
            model.cubes.append(Cube(ename, frm, to, [float(x) for x in el.get("origin", [0, 0, 0])],
                                    [float(x) for x in el.get("rotation", [0, 0, 0])], faces))
        elif kind == "mesh":
            if _nonzero(el.get("rotation")):
                model.warnings.append(f"mesh {ename!r}: rotation ignored")
            ox, oy, oz = (float(x) for x in el.get("origin", [0, 0, 0]))
            verts = el.get("vertices", {})
            mesh = Mesh(name=ename)
            tex_ids: set[int] = set()
            for face in (el.get("faces") or {}).values():
                ids = face.get("vertices", [])
                if len(ids) < 3:
                    continue
                base = mesh.vertex_count
                for vid in ids:
                    if vid not in verts:
                        raise MalformedInput(f"mesh {ename!r}: unknown vertex id {vid!r}")
                    x, y, z = verts[vid]
                    mesh.positions.extend((x + ox, y + oy, z + oz))
                    u, v = (face.get("uv") or {}).get(vid, (0.0, 0.0))
                    mesh.uvs.extend((u / rw, v / rh))
                for i in range(1, len(ids) - 1):
                    mesh.indices.extend((base, base + i, base + i + 1))
                if face.get("texture") is not None:
                    tex_ids.add(int(face["texture"]))
            if len(tex_ids) == 1:
                mesh.material = next(iter(tex_ids))
            elif len(tex_ids) > 1:
                model.warnings.append(f"mesh {ename!r}: multiple textures per mesh; using the first")
                mesh.material = min(tex_ids)
            if mesh.indices:
                model.meshes.append(mesh)
        else:
            model.warnings.append(f"element {ename!r} of type {kind!r} ignored")
    model.validate()
    return model
