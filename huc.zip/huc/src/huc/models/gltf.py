"""glTF 2.0 / GLB importer and GLB writer.

Supported: triangles/strips/fans, node hierarchies (TRS and matrix), POSITION,
NORMAL, TEXCOORD_0, embedded or external images, base-color textures.
Not supported (reported, never silently dropped): sparse accessors, skins,
animations, morph targets, KHR_* extensions beyond plain geometry.
"""
from __future__ import annotations

import base64
import json
import math
import os
import struct
from typing import Any

from ..core.errors import MalformedInput, UnsupportedFormat
from .ir import Material, Mesh, Model, Texture

GLB_MAGIC = 0x46546C67
_CT = {5120: ("b", 1, 127.0), 5121: ("B", 1, 255.0), 5122: ("h", 2, 32767.0),
       5123: ("H", 2, 65535.0), 5125: ("I", 4, None), 5126: ("f", 4, None)}
_NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
_IDENT = [1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0, 0, 0, 0, 0, 1.0]


def _mat_mul(a: list[float], b: list[float]) -> list[float]:
    return [sum(a[k * 4 + r] * b[c * 4 + k] for k in range(4)) for c in range(4) for r in range(4)]


def _trs(t, r, s) -> list[float]:
    x, y, z, w = r
    R = [[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
         [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
         [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]]
    m = [0.0] * 16
    for c in range(3):
        for r_ in range(3):
            m[c * 4 + r_] = R[r_][c] * s[c]
    m[12], m[13], m[14], m[15] = t[0], t[1], t[2], 1.0
    return m


def _node_matrix(node: dict) -> list[float]:
    if "matrix" in node:
        if len(node["matrix"]) != 16:
            raise MalformedInput("glTF node matrix must have 16 elements")
        return [float(x) for x in node["matrix"]]
    return _trs(node.get("translation", [0, 0, 0]), node.get("rotation", [0, 0, 0, 1]),
                node.get("scale", [1, 1, 1]))


def _split_glb(data: bytes) -> tuple[dict, bytes | None]:
    if len(data) < 20:
        raise MalformedInput("GLB too short")
    magic, version, length = struct.unpack_from("<III", data, 0)
    if magic != GLB_MAGIC:
        raise MalformedInput("not a GLB file")
    if version != 2:
        raise UnsupportedFormat(f"GLB version {version} (only 2 supported)")
    if length > len(data):
        raise MalformedInput("GLB length field exceeds file size")
    off, js, binchunk = 12, None, None
    while off + 8 <= length:
        clen, ctype = struct.unpack_from("<II", data, off)
        body = data[off + 8: off + 8 + clen]
        if len(body) != clen:
            raise MalformedInput("GLB chunk truncated")
        if ctype == 0x4E4F534A:
            js = json.loads(body.decode("utf-8"))
        elif ctype == 0x004E4942 and binchunk is None:
            binchunk = body
        off = (off + 8 + clen + 3) & ~3  # chunks are 4-byte aligned
    if js is None:
        raise MalformedInput("GLB has no JSON chunk")
    return js, binchunk


def _load_uri(uri: str, base_dir: str | None) -> bytes:
    if uri.startswith("data:"):
        try:
            return base64.b64decode(uri.split(",", 1)[1])
        except Exception as e:  # noqa: BLE001
            raise MalformedInput(f"bad data URI: {e}") from e
    if base_dir is None:
        raise MalformedInput(f"external resource {uri!r} but no base directory given")
    path = os.path.normpath(os.path.join(base_dir, uri))
    if not path.startswith(os.path.normpath(base_dir)):
        raise MalformedInput(f"resource path escapes base directory: {uri!r}")
    with open(path, "rb") as f:
        return f.read()


def _read_accessor(g: dict, buffers: list[bytes], idx: int) -> list[tuple]:
    acc = g["accessors"][idx]
    if "sparse" in acc:
        raise UnsupportedFormat("sparse accessors")
    fmt, size, norm = _CT[acc["componentType"]]
    n = _NC[acc["type"]]
    count = acc["count"]
    if "bufferView" not in acc:
        return [tuple([0] * n) for _ in range(count)]
    bv = g["bufferViews"][acc["bufferView"]]
    buf = buffers[bv["buffer"]]
    base = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = bv.get("byteStride") or size * n
    out = []
    try:
        for i in range(count):
            vals = struct.unpack_from("<" + fmt * n, buf, base + i * stride)
            if acc.get("normalized") and norm:
                vals = tuple(max(v / norm, -1.0) for v in vals)
            out.append(vals)
    except struct.error as e:
        raise MalformedInput(f"accessor {idx} reads past buffer end: {e}") from e
    return out


def parse_gltf(data: bytes, base_dir: str | None = None, name: str = "model") -> Model:
    if data[:4] == b"glTF":
        g, glb_bin = _split_glb(data)
    else:
        try:
            g, glb_bin = json.loads(data.decode("utf-8")), None
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise MalformedInput(f"not glTF JSON: {e}") from e
    if not str(g.get("asset", {}).get("version", "")).startswith("2"):
        raise UnsupportedFormat("only glTF 2.x is supported")

    model = Model(name=name, meta={"source_format": "gltf"})
    for key in ("skins", "animations"):
        if g.get(key):
            model.warnings.append(f"{key} present and ignored")
    for ext in g.get("extensionsRequired", []):
        raise UnsupportedFormat(f"required glTF extension {ext}")

    buffers: list[bytes] = []
    for b in g.get("buffers", []):
        if "uri" in b:
            buffers.append(_load_uri(b["uri"], base_dir))
        elif glb_bin is not None:
            buffers.append(glb_bin)
        else:
            raise MalformedInput("buffer without uri and no GLB BIN chunk")

    for i, img in enumerate(g.get("images", [])):
        if "bufferView" in img:
            bv = g["bufferViews"][img["bufferView"]]
            off = bv.get("byteOffset", 0)
            png = buffers[bv["buffer"]][off: off + bv["byteLength"]]
        elif "uri" in img:
            png = _load_uri(img["uri"], base_dir)
        else:
            png = b""
        model.textures.append(Texture(img.get("name", f"image{i}"), png))
    for i, mat in enumerate(g.get("materials", [])):
        tex = -1
        bct = mat.get("pbrMetallicRoughness", {}).get("baseColorTexture")
        if bct is not None:
            tex = g["textures"][bct["index"]].get("source", -1)
        model.materials.append(Material(mat.get("name", f"material{i}"), tex))

    def emit(node_idx: int, parent: list[float], depth: int) -> None:
        if depth > 256:
            raise MalformedInput("glTF node hierarchy too deep")
        node = g["nodes"][node_idx]
        world = _mat_mul(parent, _node_matrix(node))
        if "mesh" in node:
            _emit_mesh(g, buffers, g["meshes"][node["mesh"]], world, node.get("name"), model)
        for c in node.get("children", []):
            emit(c, world, depth + 1)

    if g.get("scenes"):
        roots = g["scenes"][g.get("scene", 0)].get("nodes", [])
    else:
        roots = list(range(len(g.get("meshes", [])))) if not g.get("nodes") else []
    if g.get("nodes"):
        for r in roots:
            emit(r, _IDENT, 0)
    else:  # no nodes: dump meshes untransformed
        for m in g.get("meshes", []):
            _emit_mesh(g, buffers, m, _IDENT, None, model)
    model.validate()
    return model


def _emit_mesh(g, buffers, mesh, world, node_name, model: Model) -> None:
    for pi, prim in enumerate(mesh.get("primitives", [])):
        mode = prim.get("mode", 4)
        if mode not in (4, 5, 6):
            model.warnings.append(f"primitive mode {mode} skipped (only triangles supported)")
            continue
        attrs = prim.get("attributes", {})
        if "POSITION" not in attrs:
            continue
        pos = _read_accessor(g, buffers, attrs["POSITION"])
        nrm = _read_accessor(g, buffers, attrs["NORMAL"]) if "NORMAL" in attrs else []
        uv = _read_accessor(g, buffers, attrs["TEXCOORD_0"]) if "TEXCOORD_0" in attrs else []
        if "indices" in prim:
            idx = [int(i[0]) for i in _read_accessor(g, buffers, prim["indices"])]
        else:
            idx = list(range(len(pos)))
        if mode == 5:
            idx = [t for i in range(len(idx) - 2)
                   for t in ((idx[i], idx[i + 1], idx[i + 2]) if i % 2 == 0
                             else (idx[i + 1], idx[i], idx[i + 2]))]
        elif mode == 6:
            idx = [t for i in range(1, len(idx) - 1) for t in (idx[0], idx[i], idx[i + 1])]
        m = world
        mm = Mesh(name=f"{node_name or mesh.get('name', 'mesh')}_{pi}", indices=idx,
                  material=prim.get("material", -1))
        for x, y, z in pos:
            mm.positions.extend((m[0] * x + m[4] * y + m[8] * z + m[12],
                                 m[1] * x + m[5] * y + m[9] * z + m[13],
                                 m[2] * x + m[6] * y + m[10] * z + m[14]))
        for x, y, z in nrm:
            nx = m[0] * x + m[4] * y + m[8] * z
            ny = m[1] * x + m[5] * y + m[9] * z
            nz = m[2] * x + m[6] * y + m[10] * z
            ln = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            mm.normals.extend((nx / ln, ny / ln, nz / ln))
        for u, v in uv:
            mm.uvs.extend((u, v))
        model.meshes.append(mm)


def write_glb(model: Model) -> bytes:
    """Serialize meshes (cubes must be tessellated first) and embedded textures."""
    model.validate()
    blob = bytearray()
    views: list[dict[str, Any]] = []
    accessors: list[dict[str, Any]] = []

    def add_view(raw: bytes, target: int | None = None) -> int:
        while len(blob) % 4:
            blob.append(0)
        views.append({"buffer": 0, "byteOffset": len(blob), "byteLength": len(raw),
                      **({"target": target} if target else {})})
        blob.extend(raw)
        return len(views) - 1

    prims = []
    for m in model.meshes:
        attrs = {}
        pv = add_view(struct.pack(f"<{len(m.positions)}f", *m.positions), 34962)
        xs, ys, zs = m.positions[0::3], m.positions[1::3], m.positions[2::3]
        accessors.append({"bufferView": pv, "componentType": 5126, "count": m.vertex_count, "type": "VEC3",
                          "min": [min(xs), min(ys), min(zs)], "max": [max(xs), max(ys), max(zs)]})
        attrs["POSITION"] = len(accessors) - 1
        if m.normals:
            nv = add_view(struct.pack(f"<{len(m.normals)}f", *m.normals), 34962)
            accessors.append({"bufferView": nv, "componentType": 5126, "count": m.vertex_count, "type": "VEC3"})
            attrs["NORMAL"] = len(accessors) - 1
        if m.uvs:
            uv = add_view(struct.pack(f"<{len(m.uvs)}f", *m.uvs), 34962)
            accessors.append({"bufferView": uv, "componentType": 5126, "count": m.vertex_count, "type": "VEC2"})
            attrs["TEXCOORD_0"] = len(accessors) - 1
        iv = add_view(struct.pack(f"<{len(m.indices)}I", *m.indices), 34963)
        accessors.append({"bufferView": iv, "componentType": 5125, "count": len(m.indices), "type": "SCALAR"})
        prim: dict[str, Any] = {"attributes": attrs, "indices": len(accessors) - 1, "mode": 4}
        if m.material >= 0:
            prim["material"] = m.material
        prims.append({"name": m.name, "primitives": [prim]})

    images: list[dict[str, Any]] = []
    tex_map: dict[int, int] = {}  # model texture index -> glTF texture index
    for ti, t in enumerate(model.textures):
        if t.data:  # textures without pixel data cannot be embedded
            tex_map[ti] = len(images)
            images.append({"name": t.name, "bufferView": add_view(t.data), "mimeType": "image/png"})
    gl: dict[str, Any] = {
        "asset": {"version": "2.0", "generator": "HUC"},
        "scene": 0, "scenes": [{"nodes": list(range(len(prims)))}],
        "nodes": [{"name": p["name"], "mesh": i} for i, p in enumerate(prims)],
        "meshes": prims, "accessors": accessors, "bufferViews": views,
        "buffers": [{"byteLength": len(blob)}],
    }
    if images:
        gl["images"] = images
        gl["textures"] = [{"source": i} for i in range(len(images))]
    if model.materials:
        mats = []
        for mt in model.materials:
            d: dict[str, Any] = {"name": mt.name}
            if mt.texture in tex_map:
                d["pbrMetallicRoughness"] = {"baseColorTexture": {"index": tex_map[mt.texture]}}
            mats.append(d)
        gl["materials"] = mats
    js = json.dumps(gl, separators=(",", ":")).encode()
    js += b" " * ((4 - len(js) % 4) % 4)
    blob.extend(b"\0" * ((4 - len(blob) % 4) % 4))
    total = 12 + 8 + len(js) + 8 + len(blob)
    return (struct.pack("<III", GLB_MAGIC, 2, total) + struct.pack("<II", len(js), 0x4E4F534A) + js
            + struct.pack("<II", len(blob), 0x004E4942) + bytes(blob))
