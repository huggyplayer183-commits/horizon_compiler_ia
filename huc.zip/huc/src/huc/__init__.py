"""Horizon Universal Compiler (HUC)."""
__version__ = "0.1.0"
