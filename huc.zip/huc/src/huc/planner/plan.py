"""Conversion planner: turns an analysis Report + a target profile into honest steps.

This is a rule-based expert system. It does not use or pretend to use a learned
model: every conclusion is traceable to a rule in this file. A step's ``tool`` is the
name of an HUC command that really implements it; ``None`` means no tool exists
(either impossible or not built yet).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.report import Level, Report
from ..knowledge.versions import TargetProfile, get_profile, parse_version

IMPLEMENTED_TOOLS = {"migrate-assets", "convert-model", "analyze"}


@dataclass
class Step:
    id: str
    title: str
    level: Level
    detail: str
    tool: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "title": self.title, "level": self.level.value,
                "detail": self.detail, "tool": self.tool}


@dataclass
class Plan:
    source: str
    target: str
    steps: list[Step] = field(default_factory=list)

    @property
    def feasible_automatically(self) -> bool:
        return all(s.level in (Level.AUTO, Level.INFO) for s in self.steps)

    def to_dict(self) -> dict[str, Any]:
        return {"source": self.source, "target": self.target,
                "feasible_automatically": self.feasible_automatically,
                "steps": [s.to_dict() for s in self.steps]}


def _family(loader: str) -> str:
    return {"forge-legacy": "forge", "forge-legacy-fml": "forge"}.get(loader, loader)


def plan_java_conversion(rep: Report, target: TargetProfile) -> Plan:
    d = rep.data
    loaders = [_family(l) for l in d.get("loaders", [])] or [_family(l) for l in d.get("loader_by_bytecode", [])]
    src_loader = loaders[0] if loaders else "unknown"
    src_ver = d.get("mc_version_hint")
    plan = Plan(f"{src_loader}@{src_ver or '?'}", f"{target.loader}@{target.mc_version or '?'}")
    S = plan.steps.append

    if target.loader == "horizon" or not target.mc_version and target.loader not in ("vanilla",):
        S(Step("target-profile", "Horizon/unknown target has no API knowledge", Level.MANUAL,
               "HUC has no built-in knowledge of the Horizon API. Provide a profile (--target-profile) and "
               "API mapping rules before any code adaptation can be planned.", None))

    if src_loader == "unknown":
        S(Step("source", "Source loader unknown", Level.MANUAL,
               "No loader metadata and no loader API in bytecode; cannot plan code conversion.", None))
    if src_ver is None:
        S(Step("source-version", "Source Minecraft version not declared", Level.PARTIAL,
               "Pass the version explicitly; bytecode alone cannot identify it reliably.", None))

    same = (src_loader == target.loader and src_ver and target.mc_version and src_ver == target.mc_version)
    if same:
        # loader+version match, but the bytecode level can still be incompatible
        mj = d.get("max_java_version")
        if mj and target.java_major and mj > target.java_major:
            S(Step("java-level", f"Classes are Java {mj}, target runs Java {target.java_major}", Level.MANUAL,
                   "Recompile from source with a lower release level.", None))
        else:
            S(Step("noop", "Source already matches target", Level.INFO, "No conversion needed.", None))
        return plan

    # ---- code
    if d.get("class_count", 0):
        scheme = d.get("mapping_scheme")
        cross_loader = src_loader not in ("unknown", target.loader)
        cross_version = bool(src_ver and target.mc_version and src_ver != target.mc_version)
        if cross_loader:
            S(Step("code-loader", f"Port code {src_loader} -> {target.loader}", Level.MANUAL,
                   "Event buses, registries, networking and lifecycle differ per loader. Requires rewriting; "
                   "HUC can list the affected API surface (see analysis api_usage) but cannot translate it.", None))
        if cross_version:
            sv, tv = parse_version(src_ver), parse_version(target.mc_version)
            gap = "across the 1.13 flattening" if sv < (1, 13) <= tv else "across Minecraft versions"
            S(Step("code-version", f"Port code {src_ver} -> {target.mc_version} {gap}", Level.MANUAL,
                   "Minecraft internals are not API-stable: registries, rendering, NBT/components, networking "
                   "and world-gen changed repeatedly. No tool can retarget bytecode safely; reconstruct against "
                   "the target's mappings.", None))
        if scheme == "srg":
            S(Step("remap", "Remap SRG -> target mappings", Level.PARTIAL,
                   "Bytecode uses SRG names. A remapper can rename symbols only when an SRG->target mapping "
                   "file exists; HUC does not ship a bytecode remapper yet.", None))
        mj = d.get("max_java_version")
        if mj and target.java_major and mj > target.java_major:
            S(Step("java-level", f"Classes are Java {mj}, target runs Java {target.java_major}", Level.MANUAL,
                   "Recompile from source with a lower release level.", None))
        if d.get("api_usage", {}).get("mixin"):
            S(Step("mixins", "Mixins must be re-targeted", Level.MANUAL,
                   "Mixin targets and injection points are tied to exact vanilla method names/descriptors.", None))
    # ---- metadata
    S(Step("metadata", "Generate loader metadata for target", Level.PARTIAL,
           "id/name/version/authors can be carried over; dependency ranges must be set by hand.", None))
    # ---- assets
    res = d.get("resources", {})
    if res.get("asset_namespaces") or res.get("data_namespaces"):
        if src_ver and parse_version(src_ver) < (1, 13) and target.mc_version:
            S(Step("assets", "Migrate pre-1.13 assets/data layout", Level.PARTIAL,
                   "Textures, model refs, lang, blockstate 'normal', simple recipes are converted; "
                   "metadata-dependent items, Forge blockstates and later schema drift are reported.",
                   "migrate-assets"))
        else:
            S(Step("assets", "Assets", Level.PARTIAL,
                   "Same-era assets often carry over, but no rule set exists for this version pair yet.", None))
    tp = get_profile(target.mc_version) if target.mc_version else None
    if tp and not tp.verified:
        S(Step("target-unverified", f"Target {target.mc_version} not in HUC's verified table", Level.MANUAL,
               "Provide pack_format/java version through a profile file; HUC will not guess.", None))
    return plan
