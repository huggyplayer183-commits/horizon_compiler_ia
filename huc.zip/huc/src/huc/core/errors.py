"""Exception hierarchy. Every failure HUC can anticipate has a dedicated type."""


class HucError(Exception):
    """Base class for all HUC errors."""


class UnsupportedFormat(HucError):
    """The input is a valid-looking format that HUC deliberately does not handle."""


class MalformedInput(HucError):
    """The input is corrupt, truncated or violates its format specification."""


class ConversionImpossible(HucError):
    """The requested conversion cannot be done automatically (needs manual work)."""


class MissingProfile(HucError):
    """A version/target profile lacks data required for a safe conversion."""
