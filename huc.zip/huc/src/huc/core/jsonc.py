"""JSON-with-comments loader.

Bedrock packs routinely contain ``//`` and ``/* */`` comments and trailing commas,
which ``json.loads`` rejects. This is a small, string-aware sanitizer.
"""
from __future__ import annotations

import json
from typing import Any

from .errors import MalformedInput


def strip_jsonc(text: str) -> str:
    out: list[str] = []
    i, n = 0, len(text)
    in_str = False
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "/":
            while i < n and text[i] != "\n":
                i += 1
        elif c == "/" and i + 1 < n and text[i + 1] == "*":
            end = text.find("*/", i + 2)
            if end == -1:
                raise MalformedInput("unterminated /* comment")
            i = end + 2
        else:
            out.append(c)
            i += 1
    return _strip_trailing_commas("".join(out))


def _strip_trailing_commas(text: str) -> str:
    out: list[str] = []
    in_str = False
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if in_str:
            out.append(c)
            if c == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 2
                continue
            if c == '"':
                in_str = False
        elif c == '"':
            in_str = True
            out.append(c)
        elif c == ",":
            j = i + 1
            while j < n and text[j] in " \t\r\n":
                j += 1
            if not (j < n and text[j] in "}]"):
                out.append(c)
        else:
            out.append(c)
        i += 1
    return "".join(out)


def loads_jsonc(data: str | bytes) -> Any:
    if isinstance(data, bytes):
        data = data.decode("utf-8-sig")
    try:
        return json.loads(strip_jsonc(data))
    except json.JSONDecodeError as e:
        raise MalformedInput(f"invalid JSON: {e}") from e
