"""Findings and reports.

Every analyzer and converter returns a Report. The ``Level`` of a finding is the
honest statement of what HUC can do about it:

* INFO         - observation, nothing to do
* AUTO         - HUC converts this automatically (and has tests for it)
* PARTIAL      - HUC converts part of it; the rest needs a human
* MANUAL       - cannot be converted by a tool; requires reconstruction
* UNSUPPORTED  - HUC does not handle this input/feature at all
"""
from __future__ import annotations

import enum
from dataclasses import dataclass, field, asdict
from typing import Any


class Level(str, enum.Enum):
    INFO = "info"
    AUTO = "auto"
    PARTIAL = "partial"
    MANUAL = "manual"
    UNSUPPORTED = "unsupported"


_SEVERITY = {Level.INFO: 0, Level.AUTO: 1, Level.PARTIAL: 2, Level.MANUAL: 3, Level.UNSUPPORTED: 4}


@dataclass
class Finding:
    code: str
    level: Level
    message: str
    path: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["level"] = self.level.value
        return d


@dataclass
class Report:
    subject: str
    kind: str
    findings: list[Finding] = field(default_factory=list)
    data: dict[str, Any] = field(default_factory=dict)

    def add(self, code: str, level: Level, message: str, path: str | None = None) -> Finding:
        f = Finding(code, level, message, path)
        self.findings.append(f)
        return f

    def worst(self) -> Level:
        if not self.findings:
            return Level.INFO
        return max((f.level for f in self.findings), key=lambda l: _SEVERITY[l])

    def count(self, level: Level) -> int:
        return sum(1 for f in self.findings if f.level == level)

    def has(self, code: str) -> bool:
        return any(f.code == code for f in self.findings)

    def to_dict(self) -> dict[str, Any]:
        return {
            "subject": self.subject,
            "kind": self.kind,
            "worst_level": self.worst().value,
            "findings": [f.to_dict() for f in self.findings],
            "data": self.data,
        }

    def format_text(self) -> str:
        lines = [f"[{self.kind}] {self.subject}  (worst: {self.worst().value})"]
        for f in self.findings:
            loc = f" ({f.path})" if f.path else ""
            lines.append(f"  {f.level.value:<11} {f.code}: {f.message}{loc}")
        return "\n".join(lines)
