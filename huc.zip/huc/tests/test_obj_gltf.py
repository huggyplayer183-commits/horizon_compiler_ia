import json
import struct
import unittest
import helpers  # noqa: F401
from huc.core.errors import MalformedInput, UnsupportedFormat
from huc.hurm.exporters import model_to_glb
from huc.models.gltf import parse_gltf, write_glb
from huc.models.ir import Material, Mesh, Model, Texture
from huc.models.obj import parse_obj, write_obj

QUAD = """
# a quad with uv + normal
mtllib q.mtl
o Quad
v 0 0 0
v 1 0 0
v 1 1 0
v 0 1 0
vt 0 0
vt 1 0
vt 1 1
vt 0 1
vn 0 0 1
usemtl Red
f 1/1/1 2/2/1 3/3/1 4/4/1
"""


class ObjTests(unittest.TestCase):
    def test_quad_is_triangulated(self):
        m = parse_obj(QUAD)
        self.assertEqual(len(m.meshes), 1)
        mesh = m.meshes[0]
        self.assertEqual(mesh.vertex_count, 4)
        self.assertEqual(mesh.indices, [0, 1, 2, 0, 2, 3])
        self.assertEqual(m.materials[0].name, "Red")
        self.assertEqual(m.meta["mtllib"], ["q.mtl"])

    def test_uv_v_is_flipped_to_top_left_origin(self):
        mesh = parse_obj(QUAD).meshes[0]
        self.assertEqual(mesh.uvs[0:2], [0.0, 1.0])  # vt 0 0 -> (0, 1)

    def test_negative_indices(self):
        m = parse_obj("v 0 0 0\nv 1 0 0\nv 0 1 0\nf -3 -2 -1\n")
        self.assertEqual(m.meshes[0].indices, [0, 1, 2])
        self.assertEqual(m.meshes[0].uvs, [])

    def test_out_of_range_index(self):
        with self.assertRaises(MalformedInput):
            parse_obj("v 0 0 0\nf 1 2 3\n")

    def test_bad_number(self):
        with self.assertRaises(MalformedInput):
            parse_obj("v a b c\n")

    def test_degenerate_face_warns(self):
        m = parse_obj("v 0 0 0\nv 1 0 0\nf 1 2\nv 0 1 0\nf 1 2 3\n")
        self.assertTrue(any("<3" in w for w in m.warnings))
        self.assertEqual(len(m.meshes), 1)

    def test_groups_split_meshes(self):
        m = parse_obj("v 0 0 0\nv 1 0 0\nv 0 1 0\no A\nf 1 2 3\no B\nf 1 2 3\n")
        self.assertEqual([x.name for x in m.meshes], ["A", "B"])

    def test_roundtrip(self):
        m = parse_obj(QUAD)
        m2 = parse_obj(write_obj(m))
        a, b = m.meshes[0], m2.meshes[0]
        self.assertEqual(a.positions, b.positions)
        self.assertEqual(a.indices, b.indices)
        for x, y in zip(a.uvs, b.uvs):
            self.assertAlmostEqual(x, y, 6)


def _tri_model():
    m = Model("tri", textures=[Texture("t.png", helpers.png_bytes())], materials=[Material("m", 0)])
    m.meshes.append(Mesh("tri", [0, 0, 0, 1, 0, 0, 0, 1, 0], [0, 0, 1] * 3, [0, 0, 1, 0, 0, 1], [0, 1, 2], 0))
    return m


class GltfTests(unittest.TestCase):
    def test_glb_roundtrip(self):
        m = parse_gltf(write_glb(_tri_model()))
        mesh = m.meshes[0]
        self.assertEqual(mesh.positions, [0, 0, 0, 1, 0, 0, 0, 1, 0])
        self.assertEqual(mesh.indices, [0, 1, 2])
        self.assertEqual(mesh.uvs, [0, 0, 1, 0, 0, 1])
        self.assertEqual(m.textures[0].data, helpers.png_bytes())
        self.assertEqual(m.materials[0].texture, 0)

    def _gltf(self, nodes, extra=None):
        pos = struct.pack("<9f", 0, 0, 0, 1, 0, 0, 0, 1, 0)
        import base64
        g = {"asset": {"version": "2.0"}, "scene": 0, "scenes": [{"nodes": [0]}], "nodes": nodes,
             "meshes": [{"primitives": [{"attributes": {"POSITION": 0}}]}],
             "accessors": [{"bufferView": 0, "componentType": 5126, "count": 3, "type": "VEC3"}],
             "bufferViews": [{"buffer": 0, "byteLength": 36}],
             "buffers": [{"byteLength": 36, "uri": "data:application/octet-stream;base64," +
                          base64.b64encode(pos).decode()}]}
        g.update(extra or {})
        return json.dumps(g).encode()

    def test_node_translation_and_scale_applied(self):
        m = parse_gltf(self._gltf([{"mesh": 0, "translation": [10, 0, 0], "scale": [2, 2, 2]}]))
        self.assertEqual(m.meshes[0].positions[:6], [10, 0, 0, 12, 0, 0])
        self.assertEqual(m.meshes[0].indices, [0, 1, 2])  # no indices -> sequential

    def test_child_node_inherits_parent_transform(self):
        nodes = [{"translation": [0, 5, 0], "children": [1]}, {"mesh": 0}]
        m = parse_gltf(self._gltf(nodes))
        self.assertEqual(m.meshes[0].positions[1], 5)

    def test_rotation_quaternion(self):
        s = 2 ** -0.5  # 90 degrees about Z
        m = parse_gltf(self._gltf([{"mesh": 0, "rotation": [0, 0, s, s]}]))
        x, y = m.meshes[0].positions[3:5]
        self.assertAlmostEqual(x, 0, 6)
        self.assertAlmostEqual(y, 1, 6)

    def test_sparse_accessor_rejected(self):
        g = json.loads(self._gltf([{"mesh": 0}]))
        g["accessors"][0]["sparse"] = {}
        with self.assertRaises(UnsupportedFormat):
            parse_gltf(json.dumps(g).encode())

    def test_required_extension_rejected(self):
        with self.assertRaises(UnsupportedFormat):
            parse_gltf(self._gltf([{"mesh": 0}], {"extensionsRequired": ["KHR_draco_mesh_compression"]}))

    def test_truncated_buffer(self):
        g = json.loads(self._gltf([{"mesh": 0}]))
        g["accessors"][0]["count"] = 100
        with self.assertRaises(MalformedInput):
            parse_gltf(json.dumps(g).encode())

    def test_bad_glb(self):
        with self.assertRaises(MalformedInput):
            parse_gltf(b"glTF" + b"\0" * 8)
        data = bytearray(write_glb(_tri_model()))
        data[4] = 1  # version 1
        with self.assertRaises(UnsupportedFormat):
            parse_gltf(bytes(data))

    def test_gltf_version_check(self):
        with self.assertRaises(UnsupportedFormat):
            parse_gltf(b'{"asset":{"version":"1.0"}}')

    def test_external_uri_path_escape_blocked(self):
        g = json.loads(self._gltf([{"mesh": 0}]))
        g["buffers"][0]["uri"] = "../../etc/passwd"
        with self.assertRaises(MalformedInput):
            parse_gltf(json.dumps(g).encode(), base_dir="/tmp/sandbox")

    def test_strip_and_fan_modes(self):
        g = json.loads(self._gltf([{"mesh": 0}]))
        g["meshes"][0]["primitives"][0]["mode"] = 5
        pos = struct.pack("<12f", 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0)
        import base64
        g["buffers"][0]["uri"] = "data:;base64," + base64.b64encode(pos).decode()
        g["buffers"][0]["byteLength"] = g["bufferViews"][0]["byteLength"] = 48
        g["accessors"][0]["count"] = 4
        m = parse_gltf(json.dumps(g).encode())
        self.assertEqual(m.meshes[0].indices, [0, 1, 2, 2, 1, 3])


if __name__ == "__main__":
    unittest.main()
