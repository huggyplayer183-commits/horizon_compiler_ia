import os
import struct
import unittest
import zlib
import helpers
from huc.core.errors import MalformedInput, UnsupportedFormat
from huc.hurm import format as hf
from huc.hurm.exporters import (model_to_glb, model_to_java_block, model_to_obj, tessellated)
from huc.core.errors import ConversionImpossible
from huc.core.report import Level
from huc.models.gltf import parse_gltf
from huc.models.ir import FACES, Cube, Material, Mesh, Model, Texture
from huc.models.obj import parse_obj

GOLDEN = os.path.join(os.path.dirname(__file__), "..", "rust", "hurm-core", "tests", "golden")


def golden_model():
    """Deterministic model; its serialization is the cross-language golden vector."""
    m = Model("golden", meta={"resolution": [16, 16]})
    m.textures.append(Texture("tex.png", helpers.png_bytes()))
    m.materials.append(Material("mat", 0))
    m.meshes.append(Mesh("tri", [0, 0, 0, 1, 0, 0, 0, 1, 0], [0, 0, 1, 0, 0, 1, 0, 0, 1],
                         [0, 0, 1, 0, 0, 1], [0, 1, 2], 0))
    m.cubes.append(Cube("c", [0, 0, 0], [8, 8, 8], [4, 4, 4], [0, 0, 22.5],
                        {"north": {"uv": [0, 0, 8, 8], "texture": 0}}))
    return m


def full_cube(name="c", frm=(0, 0, 0), to=(16, 16, 16), **kw):
    return Cube(name, list(frm), list(to), faces={f: {"uv": [0, 0, 16, 16], "texture": 0} for f in FACES}, **kw)


def chunk(tag, payload):
    return tag + struct.pack("<I", len(payload)) + payload + struct.pack("<I", zlib.crc32(payload) & 0xFFFFFFFF)


class HurmFormatTests(unittest.TestCase):
    def test_roundtrip_everything(self):
        m = golden_model()
        b = hf.read_hurm(hf.write_hurm(m))
        self.assertEqual(b.name, "golden")
        self.assertEqual(b.meshes[0].positions, m.meshes[0].positions)
        self.assertEqual(b.meshes[0].uvs, m.meshes[0].uvs)
        self.assertEqual(b.meshes[0].indices, [0, 1, 2])
        self.assertEqual(b.cubes[0].rotation, [0, 0, 22.5])
        self.assertEqual(b.textures[0].data, helpers.png_bytes())
        self.assertEqual(b.materials[0].texture, 0)

    def test_header_layout(self):
        data = hf.write_hurm(Model("x"))
        self.assertEqual(data[:4], b"HURM")
        self.assertEqual(struct.unpack_from("<HH", data, 4), (1, 0))
        self.assertEqual(data[-12:-8], b"HEND")

    def test_crc_corruption_detected(self):
        # flip a byte inside the embedded PNG: no parser besides the CRC check can notice it
        data = bytearray(hf.write_hurm(golden_model()))
        at = bytes(data).index(helpers.png_bytes()) + 20
        data[at] ^= 0xFF
        with self.assertRaises(MalformedInput) as cm:
            hf.read_hurm(bytes(data))
        self.assertIn("CRC", str(cm.exception))

    def test_truncation_detected_at_every_prefix(self):
        data = hf.write_hurm(golden_model())
        for n in range(0, len(data), 7):
            with self.assertRaises((MalformedInput, UnsupportedFormat)):
                hf.read_hurm(data[:n])

    def test_bad_magic_and_version(self):
        with self.assertRaises(MalformedInput):
            hf.read_hurm(b"NOPE" + b"\0" * 20)
        data = bytearray(hf.write_hurm(Model("x")))
        data[4] = 2
        with self.assertRaises(UnsupportedFormat):
            hf.read_hurm(bytes(data))

    def test_unknown_ancillary_chunk_is_skipped(self):
        data = hf.write_hurm(Model("x"))
        extra = chunk(b"xtra", b"future data")
        data = data[:-12] + extra + data[-12:]
        self.assertEqual(hf.read_hurm(data).name, "x")

    def test_unknown_critical_chunk_rejected(self):
        data = hf.write_hurm(Model("x"))
        data = data[:-12] + chunk(b"ZZZZ", b"?") + data[-12:]
        with self.assertRaises(UnsupportedFormat):
            hf.read_hurm(data)

    def test_missing_hend_and_trailing_data(self):
        data = hf.write_hurm(Model("x"))
        with self.assertRaises(MalformedInput):
            hf.read_hurm(data[:-12])
        with self.assertRaises(MalformedInput):
            hf.read_hurm(data + b"\0")

    def test_meta_must_be_first(self):
        data = hf.write_hurm(Model("x"))
        body = data[8:]
        meta_len = 8 + struct.unpack_from("<I", body, 4)[0] + 4
        reordered = data[:8] + body[meta_len:-12] + body[:meta_len] + body[-12:]
        with self.assertRaises(MalformedInput):
            hf.read_hurm(reordered)

    def test_invalid_model_cannot_be_written(self):
        m = Model("x")
        m.meshes.append(Mesh("bad", [0, 0, 0], [], [], [0, 1, 2]))
        with self.assertRaises(MalformedInput):
            hf.write_hurm(m)

    def test_golden_file_matches_python_writer(self):
        """The committed golden file is what the Rust tests read; keep it in sync."""
        path = os.path.join(GOLDEN, "golden.hurm")
        expected = hf.write_hurm(golden_model())
        if os.environ.get("HUC_REGEN_GOLDEN"):
            os.makedirs(GOLDEN, exist_ok=True)
            with open(path, "wb") as f:
                f.write(expected)
        with open(path, "rb") as f:
            self.assertEqual(f.read(), expected)


class ExporterTests(unittest.TestCase):
    def test_winding_matches_declared_normals(self):
        m = Model("c", textures=[Texture("t.png")], materials=[Material("t", 0)], meta={"resolution": [16, 16]})
        m.cubes.append(full_cube(frm=(1, 2, 3), to=(5, 9, 7)))
        t = tessellated(m)
        self.assertEqual(sum(x.vertex_count for x in t.meshes), 24)
        for mesh in t.meshes:
            for i in range(0, len(mesh.indices), 3):
                a, b, c = (mesh.positions[j * 3:j * 3 + 3] for j in mesh.indices[i:i + 3])
                e1 = [b[k] - a[k] for k in range(3)]
                e2 = [c[k] - a[k] for k in range(3)]
                n = [e1[1] * e2[2] - e1[2] * e2[1], e1[2] * e2[0] - e1[0] * e2[2], e1[0] * e2[1] - e1[1] * e2[0]]
                d = mesh.normals[mesh.indices[i] * 3: mesh.indices[i] * 3 + 3]
                self.assertGreater(sum(n[k] * d[k] for k in range(3)), 0)

    def test_cube_uv_normalized_by_resolution(self):
        m = Model("c", textures=[Texture("t.png")], meta={"resolution": [32, 32]})
        m.cubes.append(Cube("c", [0, 0, 0], [1, 1, 1], faces={"north": {"uv": [0, 0, 16, 16], "texture": 0}}))
        mesh = tessellated(m).meshes[0]
        self.assertEqual(max(mesh.uvs), 0.5)

    def test_single_axis_rotation_moves_vertices(self):
        m = Model("c", textures=[Texture("t.png")], meta={"resolution": [16, 16]})
        m.cubes.append(Cube("c", [0, 0, 0], [2, 2, 2], origin=[0, 0, 0], rotation=[0, 90, 0],
                            faces={"up": {"uv": [0, 0, 16, 16], "texture": 0}}))
        mesh = tessellated(m).meshes[0]
        # up-face normal is Y; rotating about Y must keep it Y, but x/z coords rotate
        self.assertAlmostEqual(mesh.normals[1], 1, 6)
        xs = {round(mesh.positions[i], 6) for i in range(0, 12, 3)}
        zs = {round(mesh.positions[i], 6) for i in range(2, 12, 3)}
        self.assertEqual(xs, {0.0, 2.0})
        self.assertEqual(zs, {0.0, -2.0})  # (x,z)->(z,-x) for +90 about Y

    def test_obj_and_glb_export_roundtrip(self):
        m = Model("c", textures=[Texture("t.png", helpers.png_bytes())], materials=[Material("t", 0)],
                  meta={"resolution": [16, 16]})
        m.cubes.append(full_cube())
        obj = parse_obj(model_to_obj(m))
        self.assertEqual(sum(x.vertex_count for x in obj.meshes), 24)
        glb = parse_gltf(model_to_glb(m))
        self.assertEqual(sum(len(x.indices) for x in glb.meshes), 36)
        self.assertEqual(glb.textures[0].data, helpers.png_bytes())

    def test_java_block_model_ok(self):
        m = Model("c", textures=[Texture("My Tex.png")], meta={"resolution": [32, 32]})
        m.cubes.append(Cube("c", [0, 0, 0], [16, 8, 16], origin=[8, 0, 8], rotation=[0, 22.5, 0],
                            faces={"north": {"uv": [0, 0, 16, 16], "texture": 0}}))
        out, rep = model_to_java_block(m, "mymod")
        el = out["elements"][0]
        self.assertEqual(el["rotation"], {"origin": [8, 0, 8], "axis": "y", "angle": 22.5})
        self.assertEqual(el["faces"]["north"], {"uv": [0.0, 0.0, 8.0, 8.0], "texture": "#0"})
        self.assertEqual(out["textures"]["0"], "mymod:block/my_tex")
        self.assertEqual(out["textures"]["particle"], "mymod:block/my_tex")
        self.assertEqual(rep.worst(), Level.AUTO)

    def test_java_block_model_flags_unrepresentable(self):
        m = Model("c", textures=[Texture("t")], meta={"resolution": [16, 16]})
        m.cubes.append(Cube("bad", [0, 0, 0], [40, 1, 1], rotation=[10, 20, 0],
                            faces={"up": {"uv": [0, 0, 16, 16], "texture": 0}}))
        m.meshes.append(Mesh("tri", [0, 0, 0, 1, 0, 0, 0, 1, 0], [], [], [0, 1, 2]))
        out, rep = model_to_java_block(m)
        codes = {f.code for f in rep.findings}
        self.assertTrue({"JBM_RANGE", "JBM_ROTATION", "JBM_MESHES", "JBM_PARTIAL"} <= codes)
        self.assertEqual(rep.worst(), Level.UNSUPPORTED)
        self.assertNotIn("rotation", out["elements"][0])  # never emits a wrong rotation

    def test_java_block_model_needs_cubes(self):
        m = Model("c")
        m.meshes.append(Mesh("tri", [0, 0, 0, 1, 0, 0, 0, 1, 0], [], [], [0, 1, 2]))
        with self.assertRaises(ConversionImpossible):
            model_to_java_block(m)


if __name__ == "__main__":
    unittest.main()
