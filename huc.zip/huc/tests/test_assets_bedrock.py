import json
import os
import tempfile
import unittest
import zipfile
import helpers
from helpers import make_zip
from huc.assets.migrate import migrate_assets, parse_lang
from huc.bedrock.analyzer import analyze_bedrock
from huc.core.errors import MalformedInput, MissingProfile
from huc.core.report import Level

SHAPED = {"type": "minecraft:crafting_shaped", "pattern": ["##", "##"],
          "key": {"#": {"item": "minecraft:planks", "data": 0}},
          "result": {"item": "oldmod:ore_block", "data": 0, "count": 1}}


def legacy_tree():
    return {
        "pack.mcmeta": '{"pack": {"pack_format": 3, "description": "Old"}}',
        "assets/oldmod/textures/blocks/Ore.png": b"P1",
        "assets/oldmod/textures/items/gem.png": b"P2",
        "assets/oldmod/textures/entity/mob.png": b"P3",
        "assets/oldmod/lang/en_US.lang": "# comment\ntile.ore.name=Ore\nitem.gem.name=Gem = Shiny\n\n",
        "assets/oldmod/models/block/ore.json": json.dumps(
            {"parent": "block/cube_all", "textures": {"all": "oldmod:blocks/Ore", "p": "#all", "q": "items/gem"}}),
        "assets/oldmod/blockstates/ore.json": json.dumps({"variants": {"normal": {"model": "oldmod:ore"}}}),
        "assets/oldmod/blockstates/forge.json": json.dumps({"forge_marker": 1, "variants": {}}),
        "assets/oldmod/recipes/ore_block.json": json.dumps(SHAPED),
        "assets/oldmod/recipes/wool.json": json.dumps(
            {"type": "minecraft:crafting_shapeless", "ingredients": [{"item": "minecraft:wool", "data": 14}],
             "result": {"item": "oldmod:red"}}),
        "assets/oldmod/recipes/smelt.json": json.dumps({"type": "forge:ore_shaped"}),
        "assets/oldmod/loot_tables/blocks/ore.json": "{}",
    }


class AssetMigrationTests(unittest.TestCase):
    def setUp(self):
        self.res = migrate_assets_from(legacy_tree(), "1.13.2")
        self.f = self.res.files

    def test_textures_moved_and_lowercased(self):
        self.assertIn("assets/oldmod/textures/block/ore.png", self.f)
        self.assertIn("assets/oldmod/textures/item/gem.png", self.f)
        self.assertIn("assets/oldmod/textures/entity/mob.png", self.f)  # untouched dir
        self.assertNotIn("assets/oldmod/textures/blocks/Ore.png", self.f)
        self.assertTrue(self.res.report.has("PATH_LOWERCASED"))

    def test_model_refs_rewritten(self):
        m = json.loads(self.f["assets/oldmod/models/block/ore.json"])
        self.assertEqual(m["textures"], {"all": "oldmod:block/ore", "p": "#all", "q": "item/gem"})
        self.assertEqual(m["parent"], "block/cube_all")

    def test_lang_converted(self):
        d = json.loads(self.f["assets/oldmod/lang/en_us.json"])
        self.assertEqual(d, {"tile.ore.name": "Ore", "item.gem.name": "Gem = Shiny"})
        self.assertNotIn("assets/oldmod/lang/en_US.lang", self.f)

    def test_blockstate_normal_renamed_and_forge_flagged(self):
        d = json.loads(self.f["assets/oldmod/blockstates/ore.json"])
        self.assertIn("", d["variants"])
        self.assertNotIn("normal", d["variants"])
        self.assertEqual(json.loads(self.f["assets/oldmod/blockstates/forge.json"])["forge_marker"], 1)
        self.assertTrue(self.res.report.has("FORGE_BLOCKSTATE"))

    def test_data_moved_and_recipe_converted(self):
        self.assertIn("data/oldmod/loot_tables/blocks/ore.json", self.f)
        r = json.loads(self.f["data/oldmod/recipes/ore_block.json"])
        self.assertNotIn("data", r["result"])
        self.assertNotIn("data", r["key"]["#"])
        self.assertEqual(r["result"]["item"], "oldmod:ore_block")

    def test_nonzero_metadata_and_forge_recipes_left_untouched_and_flagged(self):
        w = json.loads(self.f["data/oldmod/recipes/wool.json"])
        self.assertEqual(w["ingredients"][0]["data"], 14)  # original preserved
        codes = {x.code for x in self.res.report.findings}
        self.assertIn("RECIPE_METADATA", codes)
        self.assertIn("RECIPE_FORGE_TYPE", codes)
        self.assertEqual(self.res.report.worst(), Level.MANUAL)

    def test_pack_mcmeta_updated(self):
        d = json.loads(self.f["pack.mcmeta"])
        self.assertEqual(d["pack"]["pack_format"], 4)
        self.assertEqual(d["pack"]["description"], "Old")

    def test_unknown_target_needs_explicit_pack_format(self):
        with self.assertRaises(MissingProfile):
            migrate_assets_from(legacy_tree(), "26.3")
        res = migrate_assets_from(legacy_tree(), "26.3", pack_format=99)
        self.assertEqual(json.loads(res.files["pack.mcmeta"])["pack"]["pack_format"], 99)
        self.assertTrue(res.report.has("SCHEMA_DRIFT"))  # never claims full conversion for newer targets

    def test_newer_known_target_also_warns_about_drift(self):
        self.assertTrue(migrate_assets_from(legacy_tree(), "1.20.1").report.has("SCHEMA_DRIFT"))
        self.assertFalse(migrate_assets_from(legacy_tree(), "1.13.2").report.has("SCHEMA_DRIFT"))

    def test_zip_slip_rejected(self):
        evil = make_zip({"../evil.txt": "x"})
        with tempfile.NamedTemporaryFile(suffix=".zip") as f:
            f.write(evil)
            f.flush()
            with self.assertRaises(MalformedInput):
                migrate_assets(f.name, "1.13.2")

    def test_write_to_dir_and_zip_output(self):
        with tempfile.TemporaryDirectory() as d:
            self.res.write_to(d)
            self.assertTrue(os.path.exists(os.path.join(d, "assets/oldmod/textures/block/ore.png")))
        z = zipfile.ZipFile(__import__("io").BytesIO(self.res.to_zip()))
        self.assertIn("pack.mcmeta", z.namelist())

    def test_write_to_blocks_path_escape(self):
        res = migrate_assets_from({"pack.mcmeta": "{}"}, "1.13.2")
        res.files["../escape.txt"] = b"x"
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(MalformedInput):
                res.write_to(d)

    def test_parse_lang_edge_cases(self):
        self.assertEqual(parse_lang("a=b=c\n#x\n  \nnoequals\n k = v \n"), {"a": "b=c", "k": "v"})


def migrate_assets_from(tree, mc, pack_format=None):
    with tempfile.TemporaryDirectory() as d:
        for p, data in tree.items():
            full = os.path.join(d, p)
            os.makedirs(os.path.dirname(full), exist_ok=True)
            with open(full, "wb") as f:
                f.write(data if isinstance(data, bytes) else data.encode())
        return migrate_assets(d, mc, pack_format)


UUID_A, UUID_B, UUID_C = ("11111111-1111-4111-8111-111111111111", "22222222-2222-4222-8222-222222222222",
                          "33333333-3333-4333-8333-333333333333")

MANIFEST = f"""{{
  // comments are legal in Bedrock manifests
  "format_version": 2,
  "header": {{"name": "Pack", "uuid": "{UUID_A}", "version": [1, 0, 0], "min_engine_version": [1, 20, 0]}},
  "modules": [{{"type": "resources", "uuid": "{UUID_B}", "version": [1, 0, 0]}},],
}}"""

GEO = """{
  "format_version": "1.12.0",
  "minecraft:geometry": [{"description": {"identifier": "geometry.x"},
    "bones": [{"name": "body", "cubes": [{"origin": [0,0,0], "size": [1,1,1]}, {"origin": [1,1,1], "size": [1,1,1]}]},
              {"name": "head", "cubes": [{"origin": [0,2,0], "size": [1,1,1]}]}]}]
}"""


class BedrockTests(unittest.TestCase):
    def analyze(self, files):
        with tempfile.NamedTemporaryFile(suffix=".mcpack") as f:
            f.write(make_zip(files))
            f.flush()
            return analyze_bedrock(f.name)

    def test_valid_resource_pack(self):
        r = self.analyze({"manifest.json": MANIFEST, "textures/blocks/a.png": b"1", "textures/b.png": b"2",
                          "models/entity/x.geo.json": GEO, "animations/a.animation.json": "{}"})
        self.assertEqual(r.data["packs"][0]["module_types"], ["resources"])
        self.assertEqual(r.data["packs"][0]["name"], "Pack")
        self.assertEqual(r.data["content"]["textures"], 2)
        self.assertEqual(r.data["geometry"]["geometries"], 1)
        self.assertEqual((r.data["geometry"]["bones"], r.data["geometry"]["cubes"]), (2, 3))
        self.assertFalse(r.has("MANIFEST_BAD_UUID"))
        self.assertTrue(r.has("ANIMATIONS_MANUAL"))

    def test_invalid_manifest_values(self):
        bad = json.dumps({"format_version": 3, "header": {"name": "x", "uuid": "nope", "version": [1, 0]},
                          "modules": [{"type": "weird", "uuid": UUID_A}, {"type": "data", "uuid": UUID_A}]})
        r = self.analyze({"manifest.json": bad})
        codes = {f.code for f in r.findings}
        self.assertTrue({"MANIFEST_FORMAT_VERSION", "MANIFEST_BAD_UUID", "MANIFEST_BAD_VERSION",
                         "MANIFEST_UNKNOWN_MODULE", "MANIFEST_DUP_UUID"} <= codes)

    def test_behavior_pack_with_scripts_is_manual(self):
        m = json.loads(MANIFEST.replace("//", "#").split("\n", 1)[0] and
                       json.dumps({"format_version": 2, "header": {"name": "BP", "uuid": UUID_A, "version": [1, 0, 0]},
                                   "modules": [{"type": "script", "uuid": UUID_B, "version": [1, 0, 0]}],
                                   "dependencies": [{"module_name": "@minecraft/server", "version": "1.8.0"}]}))
        r = self.analyze({"manifest.json": json.dumps(m), "scripts/main.js": "import {world} from '@minecraft/server'",
                          "entities/mob.json": "{}", "blocks/b.json": "{}"})
        self.assertTrue(r.has("SCRIPTS"))
        self.assertTrue(r.has("BEHAVIOUR_DEFS"))
        self.assertEqual(r.data["packs"][0]["script_modules"], ["@minecraft/server"])
        self.assertEqual(r.worst(), Level.MANUAL)

    def test_mcaddon_with_nested_packs(self):
        rp = make_zip({"manifest.json": MANIFEST, "textures/a.png": b"1"})
        bp = make_zip({"manifest.json": MANIFEST.replace(UUID_A, UUID_C).replace(UUID_B, UUID_A)})
        r = self.analyze({"rp.mcpack": rp, "bp.mcpack": bp})
        self.assertEqual(len(r.data["packs"]), 2)
        self.assertEqual(r.data["content"]["textures"], 1)

    def test_not_a_bedrock_pack(self):
        r = self.analyze({"readme.txt": "hi"})
        self.assertTrue(r.has("NO_MANIFEST"))
        self.assertEqual(r.worst(), Level.UNSUPPORTED)

    def test_broken_manifest_json(self):
        self.assertTrue(self.analyze({"manifest.json": "{nope"}).has("MANIFEST_BAD_JSON"))

    def test_directory_input_and_legacy_geometry(self):
        legacy = json.dumps({"format_version": "1.8.0", "geometry.old": {"bones": [{"name": "b", "cubes": [{}]}]}})
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "models/entity"))
            for p, c in (("manifest.json", MANIFEST), ("models/entity/old.json", legacy)):
                with open(os.path.join(d, p), "w") as f:
                    f.write(c)
            r = analyze_bedrock(d)
        self.assertEqual(r.data["geometry"]["cubes"], 1)
        self.assertEqual(r.data["geometry"]["formats"], {"1.8.0": 1})


if __name__ == "__main__":
    unittest.main()
