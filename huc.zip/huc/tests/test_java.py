import json
import os
import shutil
import subprocess
import tempfile
import unittest
import helpers
from helpers import make_class, make_zip
from huc.core.errors import MalformedInput
from huc.core.report import Level
from huc.java import analyzer
from huc.java.analyzer import analyze_jar
from huc.java.classfile import parse_class


class ClassParserTests(unittest.TestCase):
    def test_parse_basic(self):
        data = make_class("a/b/Foo", "net/minecraft/world/item/Item", methods=[("use", "()V")],
                          fields=[("count", "I")], refs=["net/minecraftforge/fml/common/Mod", "[Lnet/minecraft/Bar;"],
                          strings=["Lnet/minecraftforge/fml/common/Mod;"],
                          member_refs=[("net/minecraft/Block", "func_149730_a", "()V")], major=61, with_long=True)
        ci = parse_class(data)
        self.assertEqual(ci.name, "a/b/Foo")
        self.assertEqual(ci.super_name, "net/minecraft/world/item/Item")
        self.assertEqual(ci.java_version, 17)
        self.assertIn(("use", "()V"), ci.methods)
        self.assertIn(("count", "I"), ci.fields)
        self.assertIn("net/minecraft/Bar", ci.class_refs)  # array unwrapped
        self.assertIn("Lnet/minecraftforge/fml/common/Mod;", ci.utf8)
        self.assertEqual((ci.member_refs[0].owner, ci.member_refs[0].name), ("net/minecraft/Block", "func_149730_a"))

    def test_long_takes_two_pool_slots(self):
        # would raise if the 2-slot rule were wrong (later entries would be misparsed)
        ci = parse_class(make_class("X", with_long=True, strings=["after-long"]))
        self.assertIn("after-long", ci.utf8)

    def test_rejects_garbage(self):
        good = make_class("X")
        for bad in (b"", b"\xca\xfe\xba\xbe", b"\x00" * 40, good[:-3], good + b"\0", good[:10]):
            with self.assertRaises(MalformedInput):
                parse_class(bad)

    def test_implausible_major_rejected(self):
        with self.assertRaises(MalformedInput):
            parse_class(make_class("X", major=3))

    @unittest.skipUnless(shutil.which("java"), "java not installed")
    def test_synthetic_class_is_accepted_by_a_real_jvm(self):
        """Validates the fixture builder itself: the JVM must load (not reject) the class."""
        with tempfile.TemporaryDirectory() as d:
            with open(os.path.join(d, "Fx.class"), "wb") as f:
                f.write(make_class("Fx", methods=[("foo", "()V")], fields=[("x", "I")], major=52))
            p = subprocess.run(["java", "-cp", d, "Fx"], capture_output=True, text=True, timeout=60)
        out = p.stdout + p.stderr
        self.assertNotIn("ClassFormatError", out)
        self.assertNotIn("Could not find or load main class", out)


def forge_legacy_jar():
    return make_zip({
        "mcmod.info": json.dumps([{"modid": "oldmod", "name": "Old Mod", "version": "1.0",
                                   "mcversion": "1.12.2", "authorList": ["me"]}]),
        "com/x/OldMod.class": make_class("com/x/OldMod", refs=["net/minecraftforge/fml/common/Mod"],
                                         strings=["Lnet/minecraftforge/fml/common/Mod;"],
                                         methods=[("func_149730_a", "()V")], major=52),
        "assets/oldmod/textures/blocks/ore.png": b"png",
        "assets/oldmod/lang/en_US.lang": b"tile.ore.name=Ore",
        "pack.mcmeta": '{"pack": {"pack_format": 3}}',
    })


class JarAnalyzerTests(unittest.TestCase):
    def test_forge_legacy(self):
        r = analyze_jar(forge_legacy_jar())
        d = r.data
        self.assertEqual(d["loaders"], ["forge-legacy"])
        self.assertEqual(d["mc_version_hint"], "1.12.2")
        self.assertEqual(d["mapping_scheme"], "srg")
        self.assertEqual(d["max_java_version"], 8)
        self.assertIn("forge", d["mod_annotations"])
        self.assertEqual(d["api_usage"]["forge"], 1)
        self.assertEqual(d["resources"]["asset_namespaces"], {"oldmod": 2})
        self.assertEqual(d["pack_format"], 3)
        self.assertTrue(r.has("MAPPING_SRG"))

    def test_fabric(self):
        fmj = {"id": "fab", "version": "1.0", "environment": "*", "depends": {"minecraft": "~1.20.1"},
               "entrypoints": {"main": ["a.B"]}, "mixins": ["fab.mixins.json", {"config": "c.json"}]}
        z = make_zip({"fabric.mod.json": json.dumps(fmj),
                      "a/B.class": make_class("a/B", refs=["net/fabricmc/api/ModInitializer", "org/spongepowered/asm/mixin/Mixin"],
                                              member_refs=[("net/fabricmc/loader/api/FabricLoader", "getInstance", "()V")],
                                              major=65)})
        r = analyze_jar(z)
        self.assertEqual(r.data["loaders"], ["fabric"])
        self.assertEqual(r.data["mc_version_hint"], "1.20.1")
        self.assertEqual(r.data["mixin_configs"], ["fab.mixins.json", "c.json"])
        self.assertEqual(r.data["max_java_version"], 21)
        self.assertTrue(r.has("USES_MIXIN"))

    def test_neoforge_vs_forge_toml(self):
        neo = '[[mods]]\nmodId="m"\n[[dependencies.m]]\nmodId="neoforge"\nversionRange="[21,)"\n[[dependencies.m]]\nmodId="minecraft"\nversionRange="[1.21.1,1.22)"\n'
        forge = '[[mods]]\nmodId="m"\n[[dependencies.m]]\nmodId="forge"\nversionRange="[47,)"\n[[dependencies.m]]\nmodId="minecraft"\nversionRange="[1.20.1,1.21)"\n'
        r1 = analyze_jar(make_zip({"META-INF/mods.toml": neo}))
        r2 = analyze_jar(make_zip({"META-INF/mods.toml": forge}))
        r3 = analyze_jar(make_zip({"META-INF/neoforge.mods.toml": neo}))
        self.assertEqual(r1.data["loaders"], ["neoforge"])
        self.assertEqual(r2.data["loaders"], ["forge"])
        self.assertEqual(r3.data["loaders"], ["neoforge"])
        self.assertEqual(r1.data["mc_version_hint"], "1.21.1")
        self.assertEqual(r2.data["mc_version_hint"], "1.20.1")

    def test_loader_mismatch_detected(self):
        z = make_zip({"fabric.mod.json": '{"id":"x","version":"1"}',
                      "a/B.class": make_class("a/B", refs=["net/minecraftforge/common/MinecraftForge"])})
        self.assertTrue(analyze_jar(z).has("LOADER_MISMATCH"))

    def test_loader_inferred_from_bytecode_when_no_metadata(self):
        z = make_zip({"a/B.class": make_class("a/B", refs=["net/neoforged/fml/ModLoadingContext"])})
        r = analyze_jar(z)
        self.assertEqual(r.data["loaders"], [])
        self.assertEqual(r.data["loader_by_bytecode"], ["neoforge"])
        self.assertTrue(r.has("NO_LOADER_METADATA"))

    def test_corrupt_class_reported_not_fatal(self):
        z = make_zip({"a/Good.class": make_class("a/Good"), "a/Bad.class": b"\xca\xfe\xba\xbe junk"})
        r = analyze_jar(z)
        self.assertEqual(r.data["class_count"], 1)
        self.assertTrue(r.has("CLASS_UNREADABLE"))
        self.assertTrue(r.has("CLASS_ERRORS"))

    def test_bad_zip(self):
        with self.assertRaises(MalformedInput):
            analyze_jar(b"this is not a zip")

    def test_zip_bomb_limit(self):
        old = analyzer.MAX_TOTAL
        analyzer.MAX_TOTAL = 10
        try:
            with self.assertRaises(MalformedInput):
                analyze_jar(make_zip({"a.txt": "x" * 100}))
        finally:
            analyzer.MAX_TOTAL = old

    def test_bad_metadata_is_reported(self):
        r = analyze_jar(make_zip({"fabric.mod.json": "{nope", "META-INF/mods.toml": "= bad", "mcmod.info": "{x"}))
        codes = {f.code for f in r.findings}
        self.assertTrue({"FABRIC_META_BAD", "TOML_BAD", "MCMOD_BAD"} <= codes)

    def test_notch_obfuscation_detected(self):
        z = make_zip({f"{c}.class": make_class(c, refs=["net/minecraft/Foo"]) for c in ("a", "b", "c")})
        self.assertEqual(analyze_jar(z).data["mapping_scheme"], "notch-obfuscated")

    def test_resource_only_jar(self):
        r = analyze_jar(make_zip({"assets/m/textures/x.png": b"1"}))
        self.assertTrue(r.has("NO_CLASSES"))


if __name__ == "__main__":
    unittest.main()
