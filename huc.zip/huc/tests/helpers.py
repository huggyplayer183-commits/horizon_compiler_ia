"""Fixture builders. They write real byte-level formats from the public specs so the
parsers are exercised on spec-shaped data, not on mocks."""
import io
import json
import struct
import sys
import os
import zipfile
import zlib

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


class ConstPool:
    def __init__(self):
        self.entries, self.cache = [], {}

    def _add(self, key, raw):
        if key not in self.cache:
            self.entries.append(raw)
            self.cache[key] = len(self.entries)
        return self.cache[key]

    def utf8(self, s):
        b = s.encode("utf-8")
        return self._add(("u", s), b"\x01" + struct.pack(">H", len(b)) + b)

    def cls(self, name):
        return self._add(("c", name), b"\x07" + struct.pack(">H", self.utf8(name)))

    def nat(self, name, desc):
        return self._add(("n", name, desc), b"\x0c" + struct.pack(">HH", self.utf8(name), self.utf8(desc)))

    def member(self, tag, owner, name, desc):
        return self._add((tag, owner, name, desc),
                         bytes([tag]) + struct.pack(">HH", self.cls(owner), self.nat(name, desc)))

    def long(self, v):  # occupies two slots
        idx = len(self.entries) + 1
        self.entries.append(b"\x05" + struct.pack(">q", v))
        self.entries.append(None)
        return idx

    def serialize(self):
        out = b"".join(e for e in self.entries if e is not None)
        return struct.pack(">H", len(self.entries) + 1) + out


def make_class(name, super_name="java/lang/Object", methods=(), fields=(), refs=(), strings=(),
               member_refs=(), major=52, with_long=False):
    cp = ConstPool()
    this_i, super_i = cp.cls(name), cp.cls(super_name)
    for r in refs:
        cp.cls(r)
    for s in strings:
        cp.utf8(s)
    for owner, n, d in member_refs:
        cp.member(10, owner, n, d)
    if with_long:
        cp.long(1234567890123)
    mem_bytes = []
    for group in (fields, methods):
        b = struct.pack(">H", len(group))
        for n, d in group:
            b += struct.pack(">HHHH", 0x0401 if group is methods else 0x0001, cp.utf8(n), cp.utf8(d), 0)
        mem_bytes.append(b)
    pool = cp.serialize()
    return (struct.pack(">IHH", 0xCAFEBABE, 0, major) + pool + struct.pack(">HHHH", 0x0421, this_i, super_i, 0)
            + mem_bytes[0] + mem_bytes[1] + struct.pack(">H", 0))


def make_zip(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in files.items():
            z.writestr(n, d if isinstance(d, (bytes, bytearray)) else d)
    return buf.getvalue()


def png_bytes():
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(b"\x00\xff\x00\x00\xff")) + chunk(b"IEND", b""))


# ---------------------------------------------------------------- binary FBX writer
def _fbx_prop(v):
    if isinstance(v, str):
        b = v.encode()
        return b"S" + struct.pack("<I", len(b)) + b
    if isinstance(v, int) and not isinstance(v, bool):
        return b"L" + struct.pack("<q", v)
    if isinstance(v, tuple):  # (type_char, list)
        t, arr = v
        fmt = {"d": "d", "i": "i", "f": "f"}[t]
        raw = struct.pack(f"<{len(arr)}{fmt}", *arr)
        comp = zlib.compress(raw)
        return t.encode() + struct.pack("<III", len(arr), 1, len(comp)) + comp
    raise TypeError(v)


def _fbx_node(name, props=(), children=(), ver=7400, pos=0):
    """Serialize a node starting at absolute offset ``pos``."""
    big = ver >= 7500
    hdr = 25 if big else 13
    nb = name.encode()
    pbytes = b"".join(_fbx_prop(p) for p in props)
    body_start = pos + hdr + len(nb) + len(pbytes)
    kids = b""
    cur = body_start
    for c in children:
        cb = _fbx_node(*c, ver=ver, pos=cur)
        kids += cb
        cur += len(cb)
    if children:
        kids += b"\x00" * hdr
        cur += hdr
    end = cur
    fmt = "<QQQ" if big else "<III"
    return struct.pack(fmt, end, len(props), len(pbytes)) + bytes([len(nb)]) + nb + pbytes + kids


def make_fbx(vertices, polys, normals=None, uvs=None, uv_index=None, ver=7400, mesh_name="Cube"):
    """vertices: flat list; polys: list of index lists (last index auto-negated);
    normals/uvs: per polygon-vertex lists (ByPolygonVertex/Direct, or IndexToDirect with uv_index)."""
    pvi = []
    for p in polys:
        pvi.extend(p[:-1] + [~p[-1]])
    geo_children = [("Vertices", [("d", vertices)]), ("PolygonVertexIndex", [("i", pvi)])]
    if normals is not None:
        geo_children.append(("LayerElementNormal", [0], [
            ("Normals", [("d", [c for n in normals for c in n])]),
            ("MappingInformationType", ["ByPolygonVertex"]), ("ReferenceInformationType", ["Direct"])]))
    if uvs is not None:
        kids = [("UV", [("d", [c for u in uvs for c in u])]),
                ("MappingInformationType", ["ByPolygonVertex"]),
                ("ReferenceInformationType", ["IndexToDirect"])]
        kids.append(("UVIndex", [("i", uv_index if uv_index is not None else list(range(len(uvs))))]))
        geo_children.append(("LayerElementUV", [0], kids))
    objects = ("Objects", [], [("Geometry", [1, mesh_name + "\x00\x01Geometry", "Mesh"], geo_children)])
    pos = 27
    out = b"Kaydara FBX Binary  \x00\x1a\x00" + struct.pack("<I", ver)
    n = _fbx_node(*objects, ver=ver, pos=len(out))
    out += n
    out += b"\x00" * (25 if ver >= 7500 else 13)
    return out
