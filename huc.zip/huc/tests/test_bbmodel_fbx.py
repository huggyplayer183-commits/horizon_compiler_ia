import base64
import json
import unittest
import helpers
from huc.core.errors import MalformedInput, UnsupportedFormat
from huc.models.bbmodel import parse_bbmodel
from huc.models.fbx import parse_fbx


def _bb(**over):
    d = {"meta": {"format_version": "4.9", "model_format": "free"}, "name": "thing",
         "resolution": {"width": 32, "height": 32},
         "elements": [{"name": "body", "type": "cube", "from": [0, 0, 0], "to": [4, 4, 4], "origin": [2, 2, 2],
                       "rotation": [0, 45, 0],
                       "faces": {"north": {"uv": [0, 0, 4, 4], "texture": 0},
                                 "up": {"uv": [4, 0, 8, 4], "texture": 0, "rotation": 90},
                                 "south": {"uv": [0, 0, 4, 4], "texture": None}}}],
         "textures": [{"name": "tex.png", "source": "data:image/png;base64," +
                       base64.b64encode(helpers.png_bytes()).decode()}],
         "outliner": []}
    d.update(over)
    return json.dumps(d)


class BbmodelTests(unittest.TestCase):
    def test_cube_import(self):
        m = parse_bbmodel(_bb())
        c = m.cubes[0]
        self.assertEqual(c.to, [4, 4, 4])
        self.assertEqual(c.rotation, [0, 45, 0])
        self.assertEqual(sorted(c.faces), ["north", "up"])  # texture None face dropped
        self.assertEqual(c.faces["up"]["rotation"], 90)
        self.assertEqual(m.textures[0].data, helpers.png_bytes())
        self.assertEqual(m.meta["resolution"], [32.0, 32.0])

    def test_inflate(self):
        d = json.loads(_bb())
        d["elements"][0]["inflate"] = 1
        c = parse_bbmodel(json.dumps(d)).cubes[0]
        self.assertEqual((c.from_, c.to), ([-1, -1, -1], [5, 5, 5]))

    def test_box_uv_is_reported_not_guessed(self):
        d = json.loads(_bb())
        d["elements"][0]["box_uv"] = True
        m = parse_bbmodel(json.dumps(d))
        self.assertEqual(m.cubes[0].faces, {})
        self.assertTrue(any("box UV" in w for w in m.warnings))

    def test_group_rotation_warns(self):
        m = parse_bbmodel(_bb(outliner=[{"name": "arm", "rotation": [10, 0, 0], "children": []}]))
        self.assertTrue(any("group rotations" in w for w in m.warnings))

    def test_mesh_element(self):
        d = json.loads(_bb())
        d["elements"] = [{"name": "m", "type": "mesh", "origin": [1, 0, 0],
                          "vertices": {"a": [0, 0, 0], "b": [1, 0, 0], "c": [1, 1, 0], "d": [0, 1, 0]},
                          "faces": {"f1": {"vertices": ["a", "b", "c", "d"], "texture": 0,
                                           "uv": {"a": [0, 0], "b": [16, 0], "c": [16, 16], "d": [0, 16]}}}}]
        m = parse_bbmodel(json.dumps(d))
        mesh = m.meshes[0]
        self.assertEqual(mesh.positions[0:3], [1, 0, 0])  # origin offset applied
        self.assertEqual(mesh.indices, [0, 1, 2, 0, 2, 3])
        self.assertEqual(mesh.uvs[2:4], [0.5, 0.0])  # 16/32
        self.assertEqual(mesh.material, 0)

    def test_unknown_vertex_id(self):
        d = json.loads(_bb())
        d["elements"] = [{"name": "m", "type": "mesh", "vertices": {"a": [0, 0, 0]},
                          "faces": {"f": {"vertices": ["a", "b", "c"]}}}]
        with self.assertRaises(MalformedInput):
            parse_bbmodel(json.dumps(d))

    def test_bad_inputs(self):
        with self.assertRaises(MalformedInput):
            parse_bbmodel("{nope")
        with self.assertRaises(MalformedInput):
            parse_bbmodel("[]")
        d = json.loads(_bb())
        d["elements"][0]["from"] = [0, 0]
        with self.assertRaises(MalformedInput):
            parse_bbmodel(json.dumps(d))

    def test_unknown_element_type_warns(self):
        d = json.loads(_bb())
        d["elements"].append({"name": "loc", "type": "locator"})
        self.assertTrue(any("locator" in w for w in parse_bbmodel(json.dumps(d)).warnings))


CUBE_V = [0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0]


class FbxTests(unittest.TestCase):
    def test_quad_with_normals_and_uv(self):
        data = helpers.make_fbx(CUBE_V, [[0, 1, 2, 3]], normals=[(0, 0, 1)] * 4,
                                uvs=[(0, 0), (1, 0), (1, 1), (0, 1)])
        m = parse_fbx(data)
        mesh = m.meshes[0]
        self.assertEqual(mesh.name, "Cube")
        self.assertEqual(mesh.vertex_count, 4)
        self.assertEqual(mesh.indices, [0, 1, 2, 0, 2, 3])
        self.assertEqual(mesh.normals[:3], [0, 0, 1])
        self.assertEqual(mesh.uvs[0:2], [0.0, 1.0])  # v flipped (FBX origin bottom-left)

    def test_uv_index_to_direct(self):
        data = helpers.make_fbx(CUBE_V, [[0, 1, 2]], uvs=[(0, 0), (1, 0), (1, 1)], uv_index=[2, 1, 0])
        mesh = parse_fbx(data).meshes[0]
        self.assertEqual(mesh.uvs, [1, 0, 1, 1, 0, 1])

    def test_version_7500_uses_64bit_offsets(self):
        data = helpers.make_fbx(CUBE_V, [[0, 1, 2]], ver=7500)
        self.assertEqual(parse_fbx(data).meshes[0].indices, [0, 1, 2])

    def test_ascii_rejected_explicitly(self):
        with self.assertRaises(UnsupportedFormat):
            parse_fbx(b"; FBX 7.3.0 project file\nFBXHeaderExtension: {}")

    def test_garbage_and_truncation(self):
        with self.assertRaises(MalformedInput):
            parse_fbx(b"not fbx at all, really")
        data = helpers.make_fbx(CUBE_V, [[0, 1, 2]])
        with self.assertRaises(MalformedInput):
            parse_fbx(data[:len(data) // 2])

    def test_out_of_range_vertex(self):
        with self.assertRaises(MalformedInput):
            parse_fbx(helpers.make_fbx(CUBE_V, [[0, 1, 9]]))

    def test_always_warns_that_transforms_are_ignored(self):
        m = parse_fbx(helpers.make_fbx(CUBE_V, [[0, 1, 2]]))
        self.assertTrue(any("transforms" in w for w in m.warnings))


if __name__ == "__main__":
    unittest.main()
