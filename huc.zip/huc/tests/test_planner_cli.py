import io
import json
import os
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
import helpers
from helpers import make_class, make_zip
from huc.cli import main
from huc.core.report import Level
from huc.hurm.format import read_hurm
from huc.java.analyzer import analyze_jar
from huc.knowledge.versions import TargetProfile
from huc.planner.plan import plan_java_conversion
from test_java import forge_legacy_jar
from test_bbmodel_fbx import _bb


def wf(path, data):
    with open(path, "wb" if isinstance(data, bytes) else "w") as f:
        f.write(data)


def rf(path):
    with open(path, "rb") as f:
        return f.read()


def step_ids(plan):
    return {s.id: s for s in plan.steps}


class PlannerTests(unittest.TestCase):
    def setUp(self):
        self.rep = analyze_jar(forge_legacy_jar())

    def test_legacy_forge_to_neoforge_requires_manual_port(self):
        plan = plan_java_conversion(self.rep, TargetProfile.for_loader("neoforge", "1.21.1"))
        s = step_ids(plan)
        self.assertFalse(plan.feasible_automatically)
        self.assertEqual(s["code-loader"].level, Level.MANUAL)
        self.assertEqual(s["code-version"].level, Level.MANUAL)
        self.assertIn("flattening", s["code-version"].title)
        self.assertEqual(s["remap"].level, Level.PARTIAL)
        self.assertEqual(s["assets"].tool, "migrate-assets")
        # a step may only name a tool that exists
        from huc.planner.plan import IMPLEMENTED_TOOLS
        self.assertTrue(all(x.tool in IMPLEMENTED_TOOLS for x in plan.steps if x.tool))

    def test_horizon_without_profile_data_is_manual(self):
        plan = plan_java_conversion(self.rep, TargetProfile("horizon", "horizon", None))
        self.assertEqual(step_ids(plan)["target-profile"].level, Level.MANUAL)

    def test_unverified_target_flagged(self):
        plan = plan_java_conversion(self.rep, TargetProfile.for_loader("neoforge", "26.3"))
        self.assertEqual(step_ids(plan)["target-unverified"].level, Level.MANUAL)

    def test_same_loader_same_version_is_noop(self):
        plan = plan_java_conversion(self.rep, TargetProfile.for_loader("forge", "1.12.2"))
        self.assertEqual([s.id for s in plan.steps], ["noop"])
        self.assertTrue(plan.feasible_automatically)

    def test_java_level_conflict(self):
        z = make_zip({"fabric.mod.json": json.dumps({"id": "x", "version": "1", "depends": {"minecraft": "1.20.1"}}),
                      "A.class": make_class("A", refs=["net/minecraft/X"], major=65)})
        plan = plan_java_conversion(analyze_jar(z), TargetProfile.for_loader("fabric", "1.20.1"))
        self.assertEqual(step_ids(plan)["java-level"].level, Level.MANUAL)

    def test_unknown_source(self):
        plan = plan_java_conversion(analyze_jar(make_zip({"x.txt": "1"})), TargetProfile.for_loader("fabric", "1.20.1"))
        self.assertEqual(step_ids(plan)["source"].level, Level.MANUAL)


class CliTests(unittest.TestCase):
    def run_cli(self, *args):
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = main(list(args))
        return code, out.getvalue(), err.getvalue()

    def test_analyze_jar_json(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "m.jar")
            wf(p, forge_legacy_jar())
            code, out, _ = self.run_cli("analyze", p, "--json")
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out)["data"]["mapping_scheme"], "srg")

    def test_convert_model_chain_bbmodel_to_hurm_obj_glb_java(self):
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "thing.bbmodel")
            wf(src, _bb())
            for ext in ("hurm", "obj", "glb", "json"):
                dst = os.path.join(d, f"out.{ext}")
                code, _o, _e = self.run_cli("convert-model", src, dst, "--namespace", "demo")
                self.assertEqual(code, 0, ext)
                self.assertGreater(os.path.getsize(dst), 10)
            self.assertEqual(len(read_hurm(rf(os.path.join(d, "out.hurm"))).cubes), 1)
            # hurm -> analyze shows the cube
            code, out, _ = self.run_cli("analyze", os.path.join(d, "out.hurm"), "--json")
            self.assertEqual(json.loads(out)["data"]["cubes"], 1)

    def test_migrate_assets_requires_known_or_explicit_pack_format(self):
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "in")
            os.makedirs(src)
            wf(os.path.join(src, "pack.mcmeta"), '{"pack":{"pack_format":3}}')
            out = os.path.join(d, "out")
            code, _o, err = self.run_cli("migrate-assets", src, out, "--mc", "26.3")
            self.assertEqual(code, 2)
            self.assertIn("pack_format", err)
            code, _o, _e = self.run_cli("migrate-assets", src, out, "--mc", "26.3", "--pack-format", "70")
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(rf(os.path.join(out, "pack.mcmeta")))["pack"]["pack_format"], 70)

    def test_unsupported_input_and_output_errors(self):
        code, _o, err = self.run_cli("analyze", "/nonexistent/file.xyz")
        self.assertEqual(code, 2)
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "a.bbmodel")
            wf(src, _bb())
            code, _o, err = self.run_cli("convert-model", src, os.path.join(d, "o.stl"))
            self.assertEqual(code, 2)

    def test_plan_cli_with_target_profile(self):
        with tempfile.TemporaryDirectory() as d:
            jar = os.path.join(d, "m.jar")
            wf(jar, forge_legacy_jar())
            prof = os.path.join(d, "horizon.json")
            wf(prof, json.dumps({"id": "horizon", "loader": "horizon", "mc_version": "26.3"}))
            code, out, _ = self.run_cli("plan", jar, "--target-profile", prof, "--json")
        self.assertEqual(code, 0)
        self.assertFalse(json.loads(out)["feasible_automatically"])


if __name__ == "__main__":
    unittest.main()
