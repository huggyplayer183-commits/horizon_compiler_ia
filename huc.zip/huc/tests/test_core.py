import unittest
import helpers  # noqa: F401
from huc.core.jsonc import loads_jsonc, strip_jsonc
from huc.core.errors import MalformedInput
from huc.core.report import Level, Report
from huc.knowledge.versions import (TargetProfile, get_profile, parse_version,
                                    require_resource_pack_format)
from huc.core.errors import MissingProfile


class JsoncTests(unittest.TestCase):
    def test_comments_and_trailing_commas(self):
        d = loads_jsonc('{ // c\n "a": [1,2,], /* x */ "b": "// not a comment", }')
        self.assertEqual(d, {"a": [1, 2], "b": "// not a comment"})

    def test_escaped_quote_in_string(self):
        self.assertEqual(loads_jsonc('{"a": "x\\"//y"}'), {"a": 'x"//y'})

    def test_bom(self):
        self.assertEqual(loads_jsonc(b'\xef\xbb\xbf{"a":1}'), {"a": 1})

    def test_unterminated_block_comment(self):
        with self.assertRaises(MalformedInput):
            strip_jsonc('{ /* nope }')

    def test_invalid_json(self):
        with self.assertRaises(MalformedInput):
            loads_jsonc("{bad")


class ReportTests(unittest.TestCase):
    def test_worst_and_counts(self):
        r = Report("x", "k")
        self.assertEqual(r.worst(), Level.INFO)
        r.add("A", Level.AUTO, "a")
        r.add("B", Level.MANUAL, "b")
        r.add("C", Level.PARTIAL, "c")
        self.assertEqual(r.worst(), Level.MANUAL)
        self.assertEqual(r.count(Level.PARTIAL), 1)
        self.assertTrue(r.has("B"))
        self.assertEqual(r.to_dict()["worst_level"], "manual")
        self.assertIn("manual", r.format_text())


class VersionTests(unittest.TestCase):
    def test_known_profile(self):
        p = get_profile("1.12.2")
        self.assertEqual((p.resource_pack_format, p.flattened, p.verified), (3, False, True))

    def test_unknown_version_is_never_guessed(self):
        p = get_profile("26.3")
        self.assertIsNone(p.resource_pack_format)
        self.assertFalse(p.verified)
        with self.assertRaises(MissingProfile):
            require_resource_pack_format("26.3")
        self.assertEqual(require_resource_pack_format("26.3", 99), 99)

    def test_parse_version(self):
        self.assertEqual(parse_version("[1.20.1,1.21)"), (1, 20, 1))
        with self.assertRaises(ValueError):
            parse_version("abc")

    def test_target_profile_requires_fields(self):
        with self.assertRaises(MissingProfile):
            TargetProfile.from_dict({"id": "x"})
        t = TargetProfile.from_dict({"id": "h", "loader": "horizon", "mc_version": "26.3"})
        self.assertEqual(t.loader, "horizon")


if __name__ == "__main__":
    unittest.main()
