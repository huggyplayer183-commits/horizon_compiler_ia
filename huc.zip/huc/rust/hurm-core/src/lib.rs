//! HUC-RM (`.hurm`) container: reader, writer and validator. See `docs/HURM_SPEC.md`.
//!
//! Zero dependencies. META / MATL / CUBE payloads are JSON and are kept as opaque
//! strings (byte-exact), so a parse -> write cycle reproduces the input bit for bit.
//! Mesh data (MESH) and textures (TEXR) are fully decoded and bounds-checked.

use std::fmt;

pub const MAGIC: &[u8; 4] = b"HURM";
pub const VERSION: u16 = 1;

#[derive(Debug, PartialEq, Eq)]
pub enum Error {
    BadMagic,
    UnsupportedVersion(u16),
    Truncated(&'static str),
    Crc([u8; 4]),
    UnknownCritical([u8; 4]),
    Structure(&'static str),
    Utf8,
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::BadMagic => write!(f, "not a .hurm file (bad magic)"),
            Error::UnsupportedVersion(v) => write!(f, "unsupported .hurm version {v}"),
            Error::Truncated(w) => write!(f, "truncated data: {w}"),
            Error::Crc(t) => write!(f, "CRC mismatch in chunk {:?}", String::from_utf8_lossy(t)),
            Error::UnknownCritical(t) => {
                write!(f, "unknown critical chunk {:?}", String::from_utf8_lossy(t))
            }
            Error::Structure(w) => write!(f, "invalid structure: {w}"),
            Error::Utf8 => write!(f, "invalid UTF-8"),
        }
    }
}

impl std::error::Error for Error {}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct Mesh {
    pub name: String,
    pub material: i32,
    pub positions: Vec<f32>,
    pub normals: Vec<f32>,
    pub uvs: Vec<f32>,
    pub indices: Vec<u32>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Texture {
    pub name: String,
    pub data: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Default)]
pub struct Hurm {
    pub meta_json: String,
    pub textures: Vec<Texture>,
    pub materials_json: String,
    pub meshes: Vec<Mesh>,
    pub cubes_json: Option<String>,
}

/// CRC-32 (IEEE 802.3), same as zlib / Python `zlib.crc32`.
pub fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xFFFF_FFFFu32;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 {
            let mask = (!(crc & 1)).wrapping_add(1);
            crc = (crc >> 1) ^ (0xEDB8_8320 & mask);
        }
    }
    !crc
}

struct Cur<'a> {
    b: &'a [u8],
    o: usize,
}

impl<'a> Cur<'a> {
    fn take(&mut self, n: usize) -> Result<&'a [u8], Error> {
        let end = self.o.checked_add(n).ok_or(Error::Truncated("length overflow"))?;
        if end > self.b.len() {
            return Err(Error::Truncated("chunk payload"));
        }
        let s = &self.b[self.o..end];
        self.o = end;
        Ok(s)
    }
    fn u8(&mut self) -> Result<u8, Error> {
        Ok(self.take(1)?[0])
    }
    fn u16(&mut self) -> Result<u16, Error> {
        let s = self.take(2)?;
        Ok(u16::from_le_bytes([s[0], s[1]]))
    }
    fn u32(&mut self) -> Result<u32, Error> {
        let s = self.take(4)?;
        Ok(u32::from_le_bytes([s[0], s[1], s[2], s[3]]))
    }
    fn i32(&mut self) -> Result<i32, Error> {
        Ok(self.u32()? as i32)
    }
    fn string(&mut self, n: usize) -> Result<String, Error> {
        String::from_utf8(self.take(n)?.to_vec()).map_err(|_| Error::Utf8)
    }
    fn f32s(&mut self, n: usize) -> Result<Vec<f32>, Error> {
        let bytes = n.checked_mul(4).ok_or(Error::Truncated("count overflow"))?;
        let s = self.take(bytes)?;
        Ok(s.chunks_exact(4).map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]])).collect())
    }
    fn u32s(&mut self, n: usize) -> Result<Vec<u32>, Error> {
        let bytes = n.checked_mul(4).ok_or(Error::Truncated("count overflow"))?;
        let s = self.take(bytes)?;
        Ok(s.chunks_exact(4).map(|c| u32::from_le_bytes([c[0], c[1], c[2], c[3]])).collect())
    }
}

fn json_string(payload: &[u8]) -> Result<String, Error> {
    String::from_utf8(payload.to_vec()).map_err(|_| Error::Utf8)
}

fn parse_mesh(payload: &[u8]) -> Result<Mesh, Error> {
    let mut c = Cur { b: payload, o: 0 };
    let nl = c.u16()? as usize;
    let name = c.string(nl)?;
    let material = c.i32()?;
    let vc = c.u32()? as usize;
    let ic = c.u32()? as usize;
    let flags = c.u8()?;
    let v3 = vc.checked_mul(3).ok_or(Error::Truncated("count overflow"))?;
    let v2 = vc.checked_mul(2).ok_or(Error::Truncated("count overflow"))?;
    let positions = c.f32s(v3)?;
    let normals = if flags & 1 != 0 { c.f32s(v3)? } else { Vec::new() };
    let uvs = if flags & 2 != 0 { c.f32s(v2)? } else { Vec::new() };
    let indices = c.u32s(ic)?;
    if c.o != payload.len() {
        return Err(Error::Structure("trailing bytes in MESH"));
    }
    if ic % 3 != 0 {
        return Err(Error::Structure("index count not a multiple of 3"));
    }
    if indices.iter().any(|&i| (i as usize) >= vc) {
        return Err(Error::Structure("index out of range"));
    }
    Ok(Mesh { name, material, positions, normals, uvs, indices })
}

/// Parse and fully validate a `.hurm` file.
pub fn parse(data: &[u8]) -> Result<Hurm, Error> {
    if data.len() < 8 || &data[0..4] != MAGIC {
        return Err(Error::BadMagic);
    }
    let version = u16::from_le_bytes([data[4], data[5]]);
    if version == 0 || version > VERSION {
        return Err(Error::UnsupportedVersion(version));
    }
    let mut out = Hurm::default();
    let (mut have_meta, mut seen_end) = (false, false);
    let mut off = 8usize;
    while off < data.len() {
        if seen_end {
            return Err(Error::Structure("data after HEND"));
        }
        if off + 8 > data.len() {
            return Err(Error::Truncated("chunk header"));
        }
        let tag = [data[off], data[off + 1], data[off + 2], data[off + 3]];
        let len = u32::from_le_bytes([data[off + 4], data[off + 5], data[off + 6], data[off + 7]]) as usize;
        let pstart = off + 8;
        let pend = pstart.checked_add(len).ok_or(Error::Truncated("chunk length"))?;
        let cend = pend.checked_add(4).ok_or(Error::Truncated("chunk length"))?;
        if cend > data.len() {
            return Err(Error::Truncated("chunk"));
        }
        let payload = &data[pstart..pend];
        let crc = u32::from_le_bytes([data[pend], data[pend + 1], data[pend + 2], data[pend + 3]]);
        if crc != crc32(payload) {
            return Err(Error::Crc(tag));
        }
        if &tag != b"META" && !have_meta {
            return Err(Error::Structure("META chunk must come first"));
        }
        match &tag {
            b"META" => {
                out.meta_json = json_string(payload)?;
                have_meta = true;
            }
            b"TEXR" => {
                let mut c = Cur { b: payload, o: 0 };
                let n = c.u16()? as usize;
                let name = c.string(n)?;
                out.textures.push(Texture { name, data: payload[c.o..].to_vec() });
            }
            b"MATL" => out.materials_json = json_string(payload)?,
            b"MESH" => out.meshes.push(parse_mesh(payload)?),
            b"CUBE" => out.cubes_json = Some(json_string(payload)?),
            b"HEND" => seen_end = true,
            _ if tag[0].is_ascii_uppercase() => return Err(Error::UnknownCritical(tag)),
            _ => {} // lowercase first letter: ancillary, skipped
        }
        off = cend;
    }
    if !have_meta {
        return Err(Error::Structure("missing META chunk"));
    }
    if !seen_end {
        return Err(Error::Structure("missing HEND chunk"));
    }
    Ok(out)
}

/// Frame one chunk: tag, length, payload, CRC32(payload).
pub fn encode_chunk(out: &mut Vec<u8>, tag: &[u8; 4], payload: &[u8]) {
    out.extend_from_slice(tag);
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    out.extend_from_slice(payload);
    out.extend_from_slice(&crc32(payload).to_le_bytes());
}

fn put_f32s(buf: &mut Vec<u8>, v: &[f32]) {
    for x in v {
        buf.extend_from_slice(&x.to_le_bytes());
    }
}

/// Serialize in canonical chunk order: META, TEXR*, MATL, MESH*, CUBE?, HEND.
pub fn write(h: &Hurm) -> Result<Vec<u8>, Error> {
    let mut out = Vec::new();
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&VERSION.to_le_bytes());
    out.extend_from_slice(&0u16.to_le_bytes());
    encode_chunk(&mut out, b"META", h.meta_json.as_bytes());
    for t in &h.textures {
        let nb = t.name.as_bytes();
        let n = u16::try_from(nb.len()).map_err(|_| Error::Structure("texture name too long"))?;
        let mut p = Vec::with_capacity(2 + nb.len() + t.data.len());
        p.extend_from_slice(&n.to_le_bytes());
        p.extend_from_slice(nb);
        p.extend_from_slice(&t.data);
        encode_chunk(&mut out, b"TEXR", &p);
    }
    encode_chunk(&mut out, b"MATL", h.materials_json.as_bytes());
    for m in &h.meshes {
        if m.positions.len() % 3 != 0 {
            return Err(Error::Structure("positions length not a multiple of 3"));
        }
        let vc = m.positions.len() / 3;
        if (!m.normals.is_empty() && m.normals.len() != vc * 3) || (!m.uvs.is_empty() && m.uvs.len() != vc * 2) {
            return Err(Error::Structure("attribute size mismatch"));
        }
        let nb = m.name.as_bytes();
        let n = u16::try_from(nb.len()).map_err(|_| Error::Structure("mesh name too long"))?;
        let flags: u8 = (!m.normals.is_empty() as u8) | ((!m.uvs.is_empty() as u8) << 1);
        let mut p = Vec::new();
        p.extend_from_slice(&n.to_le_bytes());
        p.extend_from_slice(nb);
        p.extend_from_slice(&m.material.to_le_bytes());
        p.extend_from_slice(&(vc as u32).to_le_bytes());
        p.extend_from_slice(&(m.indices.len() as u32).to_le_bytes());
        p.push(flags);
        put_f32s(&mut p, &m.positions);
        put_f32s(&mut p, &m.normals);
        put_f32s(&mut p, &m.uvs);
        for i in &m.indices {
            p.extend_from_slice(&i.to_le_bytes());
        }
        encode_chunk(&mut out, b"MESH", &p);
    }
    if let Some(c) = &h.cubes_json {
        encode_chunk(&mut out, b"CUBE", c.as_bytes());
    }
    encode_chunk(&mut out, b"HEND", &[]);
    Ok(out)
}
