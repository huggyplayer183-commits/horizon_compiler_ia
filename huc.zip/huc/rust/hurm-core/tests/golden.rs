//! Cross-language tests: `golden.hurm` is produced by the Python reference writer
//! (`tests/test_hurm.py`, regenerate with HUC_REGEN_GOLDEN=1).

use hurm_core::{crc32, encode_chunk, parse, write, Error};

const GOLDEN: &[u8] = include_bytes!("golden/golden.hurm");

#[test]
fn crc32_matches_known_vector() {
    // standard check value for CRC-32/ISO-HDLC
    assert_eq!(crc32(b"123456789"), 0xCBF4_3926);
}

#[test]
fn reads_python_written_golden_file() {
    let h = parse(GOLDEN).expect("golden must parse");
    assert!(h.meta_json.contains("\"name\":\"golden\""));
    assert_eq!(h.textures.len(), 1);
    assert_eq!(h.textures[0].name, "tex.png");
    assert_eq!(&h.textures[0].data[..8], b"\x89PNG\r\n\x1a\n");
    assert_eq!(h.meshes.len(), 1);
    let m = &h.meshes[0];
    assert_eq!(m.name, "tri");
    assert_eq!(m.material, 0);
    assert_eq!(m.positions, vec![0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0]);
    assert_eq!(m.normals.len(), 9);
    assert_eq!(m.uvs, vec![0.0, 0.0, 1.0, 0.0, 0.0, 1.0]);
    assert_eq!(m.indices, vec![0, 1, 2]);
    assert!(h.cubes_json.as_deref().unwrap().contains("\"name\":\"c\""));
}

#[test]
fn rewrite_is_byte_identical_to_python_output() {
    let h = parse(GOLDEN).unwrap();
    assert_eq!(write(&h).unwrap(), GOLDEN);
}

#[test]
fn crc_corruption_is_detected() {
    let mut d = GOLDEN.to_vec();
    let at = d.windows(4).position(|w| w == b"\x89PNG").unwrap() + 20;
    d[at] ^= 0xFF;
    assert!(matches!(parse(&d), Err(Error::Crc(_))));
}

#[test]
fn every_truncation_is_an_error() {
    for n in 0..GOLDEN.len() {
        assert!(parse(&GOLDEN[..n]).is_err(), "prefix of {n} bytes parsed");
    }
}

#[test]
fn bad_magic_and_version() {
    assert_eq!(parse(b"NOPE\0\0\0\0"), Err(Error::BadMagic));
    let mut d = GOLDEN.to_vec();
    d[4] = 2;
    assert_eq!(parse(&d), Err(Error::UnsupportedVersion(2)));
}

fn with_chunk_before_end(tag: &[u8; 4]) -> Vec<u8> {
    let mut d = GOLDEN[..GOLDEN.len() - 12].to_vec();
    encode_chunk(&mut d, tag, b"future");
    d.extend_from_slice(&GOLDEN[GOLDEN.len() - 12..]);
    d
}

#[test]
fn ancillary_chunk_skipped_critical_rejected() {
    assert!(parse(&with_chunk_before_end(b"xtra")).is_ok());
    assert_eq!(parse(&with_chunk_before_end(b"ZZZZ")), Err(Error::UnknownCritical(*b"ZZZZ")));
}

#[test]
fn trailing_data_after_end_rejected() {
    let mut d = GOLDEN.to_vec();
    d.push(0);
    assert!(parse(&d).is_err());
}
