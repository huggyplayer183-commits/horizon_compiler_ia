# Horizon Universal Compiler (HUC)

Analysis and conversion toolkit for Minecraft projects: Java mods (Forge, NeoForge, Fabric, Quilt, legacy Forge),
Bedrock add-ons / resource packs, and 3D models (OBJ, glTF/GLB, BBMODEL, binary FBX) with its own model
container **HUC-RM (`.hurm`)**.

HUC states what it can convert automatically and what needs rebuilding by a human. It does **not** claim
universal conversion. Read [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) (feasibility matrix) and
[`docs/LIMITATIONS.md`](docs/LIMITATIONS.md) (what is and isn't verified) first.

## Install / run
Requires Python >= 3.11, no third-party dependencies.
```
pip install -e .            # or: export PYTHONPATH=src
huc analyze mod.jar                       # loader, MC hint, mappings, API usage, resources
huc analyze pack.mcaddon --json           # manifests, content inventory, geometry
huc plan mod.jar --loader neoforge --mc 1.21.1       # honest, step-by-step conversion plan
huc plan mod.jar --target-profile horizon.json       # pluggable targets (e.g. Horizon)
huc migrate-assets old_mod.jar out/ --mc 1.13.2      # 1.12-style assets -> 1.13+ layout
huc convert-model thing.bbmodel thing.hurm           # also .obj .glb and .json (Java block model)
```
Target profile JSON: `{"id": "horizon", "loader": "horizon", "mc_version": "26.3", "java_major": 25, "resource_pack_format": N}`.

## Tests
```
PYTHONPATH=src python -m unittest discover -s tests     # Python (109 tests)
cd rust/hurm-core && cargo test                          # Rust (run by CI)
```
Regenerate the cross-language golden file with `HUC_REGEN_GOLDEN=1` (see `docs/HURM_SPEC.md`).

## Modules
See [`docs/MODULES.md`](docs/MODULES.md). Extending: new model format = importer returning `models.ir.Model`;
new target = profile JSON; new migration rule = function in `assets/migrate.py` + test; new loader signature =
entry in `java/signatures.py`.
