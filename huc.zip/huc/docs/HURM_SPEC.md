# HUC-RM (`.hurm`) specification, version 1

All integers little-endian. Floats IEEE-754 binary32.

## Conventions of the model IR
Right-handed, +Y up, counter-clockwise front faces, **UV origin top-left** (v grows downward, as in glTF,
Blockbench, Minecraft). OBJ and FBX importers flip v on import; the OBJ exporter flips back.
Cube coordinates are in the source's units (Blockbench: pixels, 16 = one block; see `meta.unit_scale`).
Cube rotation order is assumed to be Blockbench's **ZYX** (matrix = Rz·Ry·Rx); single-axis rotations are unambiguous.
This assumption is *not verified against Blockbench itself*.

## File layout
```
"HURM" | u16 version (=1) | u16 flags (=0, reserved) | chunk* | HEND chunk
chunk  = tag[4] | u32 length | payload[length] | u32 crc32(payload)
```
CRC is CRC-32/ISO-HDLC (zlib). Reader rules:
* `META` must be the first chunk; `HEND` the last; nothing may follow it.
* Tag first letter **uppercase = critical**: unknown -> reject. **lowercase = ancillary**: unknown -> skip (PNG rule).
  This is how the format grows without breaking old readers.
* Any CRC mismatch, truncation or out-of-range value is an error.

## Chunks (canonical write order)
| Tag | Count | Payload |
|---|---|---|
| `META` | 1 | UTF-8 JSON `{"name", "generator", "meta": {...}}` (`meta` carries source format, resolution, warnings...) |
| `TEXR` | 0..n | `u16 nameLen, name (UTF-8), PNG bytes`. Index = order of appearance. |
| `MATL` | 1 | JSON array `[{"name", "texture": int}]`, texture `-1` = none |
| `MESH` | 0..n | `u16 nameLen, name, i32 material(-1 none), u32 vertexCount, u32 indexCount, u8 flags (bit0 normals, bit1 uvs), f32 positions[3v], [f32 normals[3v]], [f32 uvs[2v]], u32 indices[indexCount]` |
| `CUBE` | 0..1 | JSON array of `{"name","from","to","origin","rotation","faces":{face:{"uv":[u1,v1,u2,v2] (pixels),"texture":int,"rotation":0/90/180/270}}}` |
| `HEND` | 1 | empty |

Validation: index count % 3 == 0, every index < vertexCount, attribute arrays sized to vertexCount,
material/texture indices in range.

## Implementations
* Python reference: `src/huc/hurm/format.py` (tested).
* Rust: `rust/hurm-core` (reads the Python-written golden file `rust/hurm-core/tests/golden/golden.hurm`
  and must re-serialize it byte-identically). Compiled/tested by CI.

## Not (yet) in v1
Compression, skeletons/animation, multiple UV sets, vertex colours, PBR parameters beyond a base texture.
Reserve ancillary tags for experiments before promoting them to critical ones.
