# HUC architecture and technical limits

## 1. What is technically possible (analysis done before building)

| Goal | Verdict | Reason |
|---|---|---|
| Analyze Java mods (Forge/NeoForge/Fabric/Quilt/legacy Forge) | **Fully possible** | Metadata files + class-file constant pool are enough to identify loader, API usage, mapping scheme, declared MC version. |
| Auto-port a mod's **code** between Minecraft versions (1.12.2 -> 26.x) | **Not possible in general** | Minecraft internals are not a stable API. The 1.13 "flattening" removed numeric ids/metadata; later versions replaced NBT with data components, rewrote rendering, networking, registries. A bytecode retargeter cannot recover intent. Needs reconstruction against the target. |
| Port code between **loaders** (Forge <-> NeoForge <-> Fabric) | **Not automatic** | Different event buses, registries, lifecycle, networking. Possible only as a guided rewrite. |
| Remap symbol names (SRG/Intermediary/Mojmap) | **Possible, needs mapping files** | Mechanical when a mapping file exists. *Not yet implemented in HUC* (roadmap). |
| Migrate **assets/data** from pre-1.13 to 1.13+ layout | **Largely possible** | Pure data transformations with documented rules. Implemented for the 1.12 -> 1.13 rule set; newer schema drift is reported, not converted. |
| Analyze Bedrock add-ons / resource packs | **Fully possible** | JSON (with comments) + zip. Implemented. |
| Convert Bedrock *behaviour* (entities/blocks/scripts) to Java | **Not possible automatically** | Component/Molang/JS-scripting model has no Java counterpart. Reconstruction. |
| Convert 3D models (OBJ, glTF/GLB, BBMODEL, binary FBX) | **Possible** | Geometry is portable. Vanilla Java models can only hold **cuboids**, so arbitrary meshes cannot become vanilla block models. |
| FBX: ASCII, skeletons, animation, node transforms | **Not implemented** | Binary geometry only; everything else is explicitly reported. |
| "Horizon" support | **Blocked on information** | HUC has no knowledge of the Horizon API. Targets are pluggable profiles (`--target-profile`); real code adaptation rules need Horizon documentation. |
| Anything for MC `26.x` | **Data missing** | pack_format / Java level for 26.x are not in HUC's verified table; the tools refuse to guess and demand a profile or explicit `--pack-format`. |

## 2. Principles

1. **Honest levels.** Every finding is `info | auto | partial | manual | unsupported` (`core/report.py`).
   `auto` means HUC converts it *and a test covers it*.
2. **Never guess silently.** Unknown versions/formats raise typed errors (`core/errors.py`) or produce findings.
3. **Safe by default.** Archive size/entry limits, zip-slip checks, path-escape checks, bounds-checked parsers, no code execution.
4. **Data, not code, for knowledge.** Version facts live in `knowledge/`; loader/API signatures in `java/signatures.py`.
5. **Pluggable.** New formats add an importer producing the shared IR; new targets add a profile.

## 3. Module map

```
src/huc/
  core/        Report/Finding/Level, errors, JSON-with-comments loader
  knowledge/   version profiles (verified flag), TargetProfile (loaders, Horizon plug-in point)
  java/        classfile.py (strict class parser) · analyzer.py (jar analysis) · signatures.py
  assets/      migrate.py  (1.12 -> 1.13+ asset/data migration)
  bedrock/     analyzer.py (manifests, content inventory, geometry)
  models/      ir.py (shared IR) · obj · gltf (+GLB writer) · bbmodel · fbx (binary)
  hurm/        format.py (.hurm reader/writer) · exporters.py (OBJ, GLB, Java block model)
  planner/     plan.py  (rule-based expert system -> honest conversion plan)
  cli.py       `huc analyze | plan | convert-model | migrate-assets`
rust/hurm-core Rust reader/writer/validator for .hurm (zero dependencies)
```

Data flow for models: `importer -> Model (IR) -> exporter`. HURM is a *serialization of the IR*, so every
importer gets every exporter for free (N + M instead of N x M converters).

## 4. About the "intelligent system"
`planner/plan.py` is a **rule-based expert system**: transparent, deterministic, testable, every conclusion traceable
to a rule. It is not a machine-learning model and does not pretend to be. Its rule base grows by adding
rules + tests. A learned component (e.g. suggesting API equivalents) could later *propose* rewrites, but
anything it proposes would still have to pass the same verification as hand-written rules.
