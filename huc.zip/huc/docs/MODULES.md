# Module reference

| Module | Purpose | Public API | Tests |
|---|---|---|---|
| `core.report` | Honest result model (`Level`, `Finding`, `Report`) | `Report.add/worst/to_dict` | test_core |
| `core.jsonc` | JSON with comments/trailing commas (Bedrock) | `loads_jsonc` | test_core |
| `core.errors` | Typed errors | `MalformedInput`, `UnsupportedFormat`, `ConversionImpossible`, `MissingProfile` | all |
| `knowledge.versions` | Version facts with a `verified` flag; `TargetProfile` | `get_profile`, `require_resource_pack_format`, `TargetProfile` | test_core |
| `java.classfile` | Strict JVM class parser (constant pool, members, refs) | `parse_class` | test_java (incl. real-JVM fixture check) |
| `java.analyzer` | Jar analysis: loaders, metadata, API usage, mapping scheme, MC hint, resources; zip limits | `analyze_jar` | test_java |
| `assets.migrate` | 1.12 -> 1.13+ assets/data migration with reporting | `migrate_assets`, `MigrationResult` | test_assets_bedrock |
| `bedrock.analyzer` | Manifest validation, content inventory, geometry stats; .mcaddon nesting | `analyze_bedrock` | test_assets_bedrock |
| `models.ir` | Shared model IR (mesh + cube) | `Model`, `Mesh`, `Cube` | test_hurm |
| `models.obj` / `gltf` / `bbmodel` / `fbx` | Importers (GLB also exports) | `parse_obj`, `parse_gltf`, `write_glb`, `parse_bbmodel`, `parse_fbx` | test_obj_gltf, test_bbmodel_fbx |
| `hurm.format` | `.hurm` reader/writer (spec: HURM_SPEC.md) | `read_hurm`, `write_hurm` | test_hurm |
| `hurm.exporters` | Cube tessellation, OBJ, GLB, Java block-model JSON (with feasibility report) | `tessellated`, `model_to_obj`, `model_to_glb`, `model_to_java_block` | test_hurm |
| `planner.plan` | Rule-based conversion planner | `plan_java_conversion` | test_planner_cli |
| `cli` | Command line | `huc ...` | test_planner_cli |
| `rust/hurm-core` | Rust `.hurm` reader/writer/validator | `parse`, `write`, `crc32` | `tests/golden.rs` (CI) |
